-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2019 at 06:23 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel_tut`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `c_id` bigint(20) UNSIGNED NOT NULL,
  `cname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`c_id`, `cname`, `created_at`, `updated_at`) VALUES
(1, 'MCA', '2019-07-30 08:17:51', '2019-07-30 08:17:51'),
(2, 'IMCA', '2019-07-30 08:18:00', '2019-07-30 08:18:00');

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `f_id` bigint(20) UNSIGNED NOT NULL,
  `fname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `femail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `femail_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`f_id`, `fname`, `femail`, `femail_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Sarojkumar', 'sarojlal50@gmail.com', NULL, '$2y$10$BhpwI5grvrZ/y50PT9ry9.41ZR.9DQEpi5DowcAy54vp4y2QjcBRS', NULL, '2019-07-30 08:14:12', '2019-07-30 08:14:12'),
(2, 'pk', 'pk@gmail.com', NULL, '$2y$10$RZ1evdBw756J/.pb63UxdOXj.NTIaXti7/QPBKARWYpYpnsRBTH0S', NULL, '2019-07-30 08:33:41', '2019-07-30 08:33:41');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(3, '2019_06_27_131556_create_profs_table', 1),
(11, '2014_10_12_000000_create_users_table', 2),
(12, '2014_10_12_100000_create_password_resets_table', 2),
(13, '2019_07_08_033450_create_faculties_table', 2),
(14, '2019_07_17_142806_create_uploads_table', 2),
(15, '2019_07_25_184007_create_students_table', 2),
(16, '2019_07_27_141937_create_courses_table', 2),
(17, '2019_07_27_232254_create_sems_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profs`
--

CREATE TABLE `profs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pwd` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sems`
--

CREATE TABLE `sems` (
  `sem_id` bigint(20) UNSIGNED NOT NULL,
  `c_id` bigint(20) NOT NULL,
  `sem` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sems`
--

INSERT INTO `sems` (`sem_id`, `c_id`, `sem`, `created_at`, `updated_at`) VALUES
(1, 1, 'Sem-1', '2019-07-30 08:20:02', '2019-07-30 08:20:02'),
(2, 1, 'Sem-2', '2019-07-30 08:20:11', '2019-07-30 08:20:11'),
(3, 1, 'Sem-3', '2019-07-30 08:20:19', '2019-07-30 08:20:19'),
(4, 1, 'Sem-4', '2019-07-30 08:20:32', '2019-07-30 08:20:32'),
(5, 1, 'Sem-5', '2019-07-30 08:20:48', '2019-07-30 08:20:48'),
(6, 1, 'Sem-6', '2019-07-30 08:20:56', '2019-07-30 08:20:56'),
(7, 2, 'Sem-1', '2019-07-30 08:21:24', '2019-07-30 08:21:24'),
(8, 2, 'Sem-2', '2019-07-30 08:21:32', '2019-07-30 08:21:32');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `sid` bigint(20) UNSIGNED NOT NULL,
  `enroll_no` bigint(20) NOT NULL,
  `sname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course` int(11) NOT NULL,
  `sem` int(11) NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`sid`, `enroll_no`, `sname`, `semail`, `password`, `course`, `sem`, `class`, `created_at`, `updated_at`) VALUES
(1, 185173693045, 'Sarojkumar Rambachan Lal', 'shivasarojlal@gmail.com', '$2y$10$XuQSPQZLm6YGrOFa9oSwb.FBbrFPSZHy9E4ZX8hlT5X2ALyqpWJHK', 1, 5, 'A', '2019-07-30 10:47:34', '2019-07-30 10:47:34'),
(2, 185173693042, 'Abcd', 'abc@gmail.com', '$2y$10$V00m8v/cuPjFMMFf8z/tN.ifaVa86Qom7tE7gp8swGWzFSENYh2B.', 1, 5, 'A', '2019-07-31 04:04:13', '2019-07-31 04:04:13');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `uid` bigint(20) UNSIGNED NOT NULL,
  `uploads` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f_id` int(11) DEFAULT NULL,
  `course` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `class` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`uid`, `uploads`, `f_id`, `course`, `sem`, `class`, `created_at`, `updated_at`) VALUES
(2, 'Certificate_Hadoop.pdf', 1, NULL, NULL, NULL, '2019-07-30 08:32:27', '2019-07-30 08:32:27'),
(3, 'jquery-3.4.1.min.js', 2, NULL, NULL, NULL, '2019-07-30 08:36:11', '2019-07-30 08:36:11'),
(4, 'BigDataUniversity BD0111EN Certificate _ Cognitive Class.pdf', 1, 1, 5, 'A', '2019-07-30 12:08:31', '2019-07-30 12:08:31'),
(5, 'imm1294e.pdf', 1, 1, 2, 'B', '2019-07-30 12:47:39', '2019-07-30 12:47:39'),
(6, 'TCS_ApplicationForm.pdf', 1, 2, 7, 'A', '2019-07-31 01:13:32', '2019-07-31 01:13:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`f_id`),
  ADD UNIQUE KEY `faculties_femail_unique` (`femail`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profs`
--
ALTER TABLE `profs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sems`
--
ALTER TABLE `sems`
  ADD PRIMARY KEY (`sem_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `c_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `f_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `profs`
--
ALTER TABLE `profs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sems`
--
ALTER TABLE `sems`
  MODIFY `sem_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `sid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `uid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
