# -*- coding: utf-8 -*-
"""
Created on Fri Feb 08 17:49:00 2019

@author: shiva
"""


import matplotlib.pyplot as mp
import pandas as pd
import pylab as pl
import numpy as np

df=pd.read_csv("C:/Users/shiva/Documents/ndsap_visa_info_JAN_2014.csv",delimiter=",")
print(type(df))
print(df)
visit_visa=(df.loc[:,['VISIT_VISA_IN_NO']])
business_visa=(df.loc[:,['BUSINESS_VISA_IN_NO']]);
#business_visa=(df.loc[:,['TOURIST_VISA_IN_NO']]);
#print(business_visa)
coun=list(df.loc[:,['COUNTRY']])
y_coun=np.arange(len(coun))
mp.plot(visit_visa,color="r",linewidth=2,label="visit_visa")
mp.plot(business_visa,color="g",linewidth=2,label="business_visa")
#mp.bar(tourist_visa,color="b",height=100,linewidth=2,label="tourist_visa")
mp.xlabel("Countries")
mp.ylabel("No of persons")
#mp.hist(tourist_visa)
pl.legend()
mp.show()
#print(visa)
