<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFassignmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fassignments', function (Blueprint $table) {
            $table->bigIncrements('assig_id');
            $table->string('document');
            $table->string('desc');
            $table->string('f_id');
            $table->integer('course');
            $table->integer('sem_id');
            $table->string('class');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fassignments');
    }
}
