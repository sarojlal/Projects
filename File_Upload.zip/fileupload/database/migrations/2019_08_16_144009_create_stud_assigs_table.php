<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudAssigsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('studentassigs', function (Blueprint $table) {
            $table->bigIncrements('sa_id');
            $table->string('assignment');
            $table->bigInteger('ass_id');
            $table->bigInteger('fid');
            $table->bigInteger('stud_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('studentassigs');
    }
}
