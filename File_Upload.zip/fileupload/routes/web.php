<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/registerfacul','facultiesController@register');
Route::get('/registerfacul',function () {
    return view('registerfacul');
});
Route::get('/registerstud','StudentsController@register');
Route::post('/insertfacul','facultiesController@insertfacul');
Route::post('/insertstud','StudentsController@insertstud');
Route::post('/insert','HomeController@insert')->name('register');
Route::get('/',function () {
    return view('facultylogin');
});
Route::post('/faculty-login','Auth\FacultyLoginController@multilogin');

//Routes for Forgot Pwd
Route::get('/forgot-password','ForgotPwdController@forgot');
Route::get('/forgot-pwd','ForgotPwdController@sendEmail');
Route::get('/reset_pwd/{id}','ForgotPwdController@show');
Route::match(['get','post'],'/reset-password-final/{id}','ForgotPwdController@reset_pwd');

Auth::routes();

//Faculty-Routes group
Route::group(['middleware' => ['faculty']], function (){

    //Faculty Routes
    Route::get('/header',function () {
        return view('header');
    });
    Route::get('/viewfaculties','facultiesController@view');
    Route::get('/viewfaculty','facultiesController@home');
    Route::get('/update/{f_id}','facultiesController@update');
    Route::post('/edit/{f_id}','facultiesController@edit');
    Route::get('/delete/{f_id}','facultiesController@delete');

    //Upload Routes
    Route::get('/fileupload','UploadController@index');
    Route::get('/deleteupload/{uid}','UploadController@delete');
    Route::get('/viewuploads','UploadController@show');
    Route::post('/store','UploadController@store');

    //Assignment Routes
    Route::get('/faculty-assignment','AssigController@index');
    Route::post('/assig-store','AssigController@store');
    Route::get('/viewassignments','AssigController@view');
    Route::get('/deleteassig/{assig_id}','AssigController@delete');
    Route::get('/viewsubmissions/{ass_id}','AssigController@viewsub');
    Route::post('/submitmarks','AssigController@submitmarks');
});

//Stud-Routes group
Route::group(['middleware' => ['student']], function (){
    Route::get('/viewfiles','UploadController@home');
    Route::get('/viewassigs','UploadController@viewassig');
    //Stud-assig Routes
    Route::post('/studassig-store','StudAssigController@store');
    Route::get('/stud_assig_upload','StudAssigController@view');
    Route::get('/viewassigs','UploadController@viewassig');
    Route::get('/viewmarks','StudAssigController@viewmarks');
});

//Faculty-Routes group
Route::group(['middleware' => ['guest']], function (){

//routes to check for login first
// Route::get('/header',function () {
//     return view('header');
// });

Route::get('/bulkupload', 'facultiesController@viewBulkPage');
Route::post('/uploadFile', 'facultiesController@uploadFile');

Route::get('/headerstud',function () {
    return view('student_header');
});
Route::get('/demo',function () {
    return view('demo');
});

//Faculties Routes
Route::get('/viewfaculties','facultiesController@view');
Route::get('/viewfaculty','facultiesController@home');
Route::get('/update/{f_id}','facultiesController@update');
Route::post('/edit/{f_id}','facultiesController@edit');
Route::get('/delete/{f_id}','facultiesController@delete');



Route::get('/home', 'HomeController@index')->name('home');




//Course Routes
Route::post('/add-course','CourseController@insert')->name('add-course');
Route::get('/course',function () {
    return view('addcourse');
});
Route::get('/viewcourses','CourseController@view');
Route::get('/updatef/{c_id}','CourseController@update');
Route::post('/editf/{c_id}','CourseController@edit');
Route::get('/deletef/{c_id}','CourseController@delete');

//Students
Route::get('/viewstudents','StudentsController@home');
Route::get('/updates/{sid}','StudentsController@update');
Route::post('/edits/{sid}','StudentsController@edit');
Route::get('/deletes/{sid}','StudentsController@delete');

//Sem
Route::post('/add-sem','SemController@insert');
Route::get('/sem','SemController@home');
Route::get('/updatesem/{sem_id}','SemController@update');
Route::post('/editsem/{sem_id}','SemController@edit');
Route::get('/deletesem/{sem_id}','SemController@delete');
Route::get('/viewsem','SemController@view');

});