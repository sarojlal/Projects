<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class uploads extends Model
{
    protected $primaryKey = 'uid';
    protected $fillable = ['uploads','f_id','course','sem','class'];
}
