<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;
// use Illuminate\Contracts\Auth\Authenticatable;
// use Illuminate\Contracts\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\CanResetPassword;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Faculty extends Authenticatable
{
    use Notifiable;

    protected $guard = 'faculty';
    protected $primaryKey = 'f_id';
    protected $fillable = ['fname','femail','password'];

    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    protected $table = 'faculties';

    //Insert bulk data(CSV)
    public static function insertData($data){

        $value=DB::table('faculties')->where('fname', $data['fname'])->get();
        if($value->count() == 0){
           DB::table('faculties')->insert($data);
        }
     }
}
