<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fassignment extends Model
{
    protected $primaryKey = 'assig_id';
    protected $fillable = ['document','desc','f_id','course','sem_id','class'];
}
