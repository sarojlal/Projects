<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudAssig extends Model
{
    protected $table = 'studentassigs';
    protected $primaryKey = 'sa_id';
    protected $fillable = ['assignment','ass_id','fid','stud_id'];
}
