<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class marks extends Model
{
    protected $primaryKey = 'mid';
    protected $fillable = ['assig_id','assig_name','stud_id','marks','f_id'];
    protected $table = 'marks';
}
