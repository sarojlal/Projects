<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sem extends Model
{
    protected $primaryKey = 'sem_id';
    protected $fillable = ['c_id','sem'];
}
