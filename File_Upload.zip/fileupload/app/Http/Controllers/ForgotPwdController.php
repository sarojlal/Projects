<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Faculty;
use App\Student;
use Illuminate\Mail\Message;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMailable; 
//namespace Illuminate\Foundation\Auth;

class ForgotPwdController extends Controller
{
    public function forgot(){
        return view("forgot_password");
    }
    public function password(Request $request){
        $faculty = Faculty::whereEmail($request->email)->first();
        if(count($faculty) == 0){
            return view('forgot_password')->with('info','Email does not exist');
        }
    }
    public function sendEmail(Request $request)
    {
        // $email_address = $request->input('email');
        // $credentials = ['femail' => $email_address];

        // if($credentials > 0){
        //     return $email_address;
        // }
        // else {
        //     return 'Not found';
        // }
        // $response = Password::sendResetLink($credentials, function (Message $message) {
        //     $message->subject($this->getEmailSubject());
        // });

        // switch ($response) {
        //     case Password::RESET_LINK_SENT:
        //         return redirect('/forgot-password')->with('status', trans($response));
        //     case Password::INVALID_USER:
        //         return redirect('/forgot-password')->withErrors(['femail' => trans($response)]);
        // }
        $femail = Faculty::where('femail', '=', Input::get('email'))->first();
        $email = $femail['femail'];
        $id = $femail['f_id'];
        $name = $femail['fname'];
        // if ($femail === null) {
        //     return 'Not found';
        // }
        // else{
        //     return 'Found';
        // }
        

        // $semail = Student::where('email', $request->input('email'))->first();
        //$token = Password::getRepository()->create($femail);

        $link = "http://127.0.0.1:8000/reset_pwd/" . $id;
        if($femail != null){
        Mail::to($email)->send(new SendMailable($link,$name));
        return redirect('/' )->with('mail','Password reset link is sent to registered Email ID !!');
        }
        else{
            return redirect('/')->with('info','Email not registered!!');
        }
    }
    public function show($id){
        $faculty = Faculty::find($id);
        if($faculty === null){
            return redirect('/')->with('info','Email Not registered!!');
        }
        else{
            return view('reset-password',['faculties' => $faculty]);
        }
    }
    public function reset_pwd(Request $request,$id){
        $pwd = bcrypt($request->input('password'));
        $data = array(
            'password' => bcrypt($request->input('password'))
        );
        $fac = Faculty::find($id);
        if($pwd === null){
            return redirect('/')->with('info','Email not registered!!');
        }
        else{
            Faculty::where('f_id',$id)->update($data);
            return redirect('/' )->with('mail','Password Changed Successfully!!');
        }
    }
    public function update($f_id){
        $faculty = Faculty::find($f_id);
        return view('updatefaculty',['faculties' => $faculty]);
    }
    public function edit(Request $request, $f_id){
        /*$profiles = prof::find($id);
        return view('update',['profs' => $profiles]);*/
        $data = array(
            'fname' => $request->input('fname'),
            'femail' => $request->input('femail'),
            'password' => $request->input('fpwd')
        );
        Faculty::where('f_id',$f_id)-> update($data);
        return redirect('/viewfaculties')->with('info','Data Updated successfully');
    }

}
