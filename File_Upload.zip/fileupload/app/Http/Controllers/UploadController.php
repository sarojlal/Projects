<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File as LaraFile;
use App\uploads;
use App\fassignment;
use App\Faculty;
use App\Course;
use App\Student;
use App\Sem;
use Auth;
use DB;

class UploadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // return view('fileupload');
        $upload = uploads::all();
        $faculty = Faculty::all();
        $course = Course::all();
        $sem = Sem::all();
        $q1 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=c.c_id && c.c_id =1");
        $q2 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=c.c_id && c.c_id =2");
        return view('fileupload',['uploades' => $upload,'faculties' => $faculty ,'courses' => $course , 'sems' => $sem,'qry1' => $q1 ,'qry2' => $q2]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function delete($uid)
    {
        // $upload = uploads::find($uid);
        // uploads::delete($upload->uploads);
        // // else{return 'Error';}
        // $upload->delete();

        // $upload = uploads::findOrFail($uid);
        // // unlink(public_path() .$upload->public->uploads);
        // LaraFile::delete('uploads/'.'$uid');
        // $upload->delete();

        $upload = uploads::find($uid);
        $image = \DB::table('uploads')->where('uid', $uid)->first();
        $file = $upload->uploads;
        $filename = public_path().'/uploads/'.$file;
        \File::delete($filename);
        uploads::where('uid',$uid) -> delete();


        return redirect('/viewuploads')->with('info','File Deleted Successfully!!');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id=Auth::guard('faculty')->user()->f_id;
        // dd($request);
        $this->validate($request,[
            'uploads' => 'required',
            'course' => 'required',
            'sem' => 'required',
            'class' => 'required|max:2'
        ]);
        
        if($file = $request->file('uploads')){
            
            $name = $file->getClientOriginalName();
            if($file->move('uploads',$name)){
                $upload = new uploads;
                $upload->uploads = $name;
                $upload->f_id = $id;
                $upload->course = $request->input('course');
                $upload->sem = $request->input('sem');
                $upload->class = $request->input('class');
                $upload->save();
                return redirect('/viewuploads')->with('info','File Uploaded Successfully!!');
            };

        }
        else{
            return redirect('/facultyupload')->with('info','File was not Uploaded !!');
        }

    }
    public function downloadfun(){
        $downloads = DB::table('uploads').get();
        return view('viewuploads',compact('uploads'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $upload = uploads::all();
        $faculty = Faculty::all();
        return view('viewuploads',['uploades' => $upload,'faculties' => $faculty]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    public function home(){
        $stud_sem =  Auth::guard('student')->user()->sem;
        $stud_course = Auth::guard('student')->user()->course;
        $data =array(
            'sem' => $stud_sem,
            'course' => $stud_course,
        );
        $upload_data = uploads::where($data);
        $uploads = uploads::all();
        $students = Student::all();
        $courses = Course::all();
        $sems = Sem::all();
        $faculties = Faculty::all();
        $datas = array($students[0]->course == $uploads[0]->course,$students[0]->sem == $uploads[0]->sem) ;
        //return view('viewfiles',['faculties' => $faculty,'students' => $student , 'courses' => $course , 'sems' => $sem,'uploads' => $upload]);
        return view('viewfiles',compact('upload_data','datas','uploads','students','courses','sems','faculties'));
    }
    public function viewassig(){
        $stud_sem =  Auth::guard('student')->user()->sem;
        $stud_course = Auth::guard('student')->user()->course;
        $data =array(
            'sem' => $stud_sem,
            'course' => $stud_course,
        );
        $uploads = uploads::all();
        $students = Student::all();
        $courses = Course::all();
        $sems = Sem::all();
        $faculties = Faculty::all();
        $assigs = fassignment::all();
        return view('viewassigs_stud',compact('assigs','upload_data','uploads','students','courses','sems','faculties'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
