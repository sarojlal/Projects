<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Faculty;
use Illuminate\Contracts\Auth\Authenticatable;
use Auth;
use Redirect;
use Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

class facultiesController extends Controller
{
    public function register(){
        return view('registerfacul');
    }

    //function for CSV upload
    public function uploadFile(Request $request){

        if ($request->input('submit') != null ){
    
          $file = $request->file('uploads');
    
          // File Details 
          $filename = $file->getClientOriginalName();
          $extension = $file->getClientOriginalExtension();
          $tempPath = $file->getRealPath();
          $fileSize = $file->getSize();
          $mimeType = $file->getMimeType();
    
          // Valid File Extensions
          $valid_extension = array("csv");
    
          // 2MB in Bytes
          $maxFileSize = 2097152; 
    
          // Check file extension
          if(in_array(strtolower($extension),$valid_extension)){
    
            // Check file size
            if($fileSize <= $maxFileSize){
    
              // File upload location
              $location = 'CSVuploads';
    
              // Upload file
              $file->move($location,$filename);
    
              // Import CSV to Database
              $filepath = public_path($location."/".$filename);
    
              // Reading file
              $file = fopen($filepath,"r");
    
              $importData_arr = array();
              $i = 0;
    
              while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                 $num = count($filedata );
                 
                 // Skip first row (Remove below comment if you want to skip the first row)
                 /*if($i == 0){
                    $i++;
                    continue; 
                 }*/
                 for ($c=0; $c < $num; $c++) {
                    $importData_arr[$i][] = $filedata [$c];
                 }
                 $i++;
              }
              fclose($file);
    
              // Insert to MySQL database
              foreach($importData_arr as $importData){
    
                $insertData = array(
                   "fname"=> (isset($importData[0]) ? $importData[0] : ''),
                   "femail"=>(isset($importData[1]) ? $importData[1] : ''),
                   "password"=>bcrypt(isset($importData[2]) ? $importData[2] : ''));
                Faculty::insertData($insertData);
              }
    
              Session::flash('message','Import Successful.');
            }else{
              Session::flash('message','File too large. File must be less than 2MB.');
            }
    
          }else{
             Session::flash('message','Invalid File Extension.');
          }
    
        }
    
        // Redirect to index
        return redirect()->action('facultiesController@viewBulkPage');
      }

    public function insertfacul(Request $request){
        #$faculty = Faculty::all();
        $this->validate($request,[
            'fname' => 'required',
            'femail' => 'required',
            'fpwd' => 'required'
        ]);
        //return 'Validation Pass';
        $faculties=new Faculty;
        $faculties->fname = $request->input('fname');
        $faculties->femail = $request->input('femail');
        $faculties->password = bcrypt($request->input('fpwd'));
        $faculties->save();
        return redirect('/viewfaculties')->with('info','Data Inserted successfully');
    }
    public function viewBulkPage(){
        return view('csv_faculty_upload');
    }
    public function home(){
        $faculty = Faculty::all();
        return view('viewfaculties',['faculties' => $faculty]);
    }
    public function view(){
        $faculty = Faculty::all();
        return view('viewfaculties',['faculties' => $faculty]);
    }
    public function login(Request $request){
        $this->validate($request,[
            
            'femail'=>'required|email|max:255',

            'fpwd'=>'required|max:255'
        ]);
        if(Auth::guard('faculty')->attempt(array('femail'=>$request->femail,'fpwd'=>$request->fpassword))){
            return 'Logged In Successfully';
        }else{
            return 'ERROR!!';
        }
    }

    public function update($f_id){
        $faculty = Faculty::find($f_id);
        return view('updatefaculty',['faculties' => $faculty]);
    }
    public function edit(Request $request, $f_id){
        /*$profiles = prof::find($id);
        return view('update',['profs' => $profiles]);*/
        $data = array(
            'fname' => $request->input('fname'),
            'femail' => $request->input('femail'),
            'password' => $request->input('fpwd')
        );
        Faculty::where('f_id',$f_id)-> update($data);
        return redirect('/viewfaculties')->with('info','Data Updated successfully');
    }
    public function delete($id){
        Faculty::where('f_id',$id) -> delete();
        return redirect('/viewfaculties')->with('info','Data Deleted successfully');
    }
    
    public function postLogin(){
    // Creating Rules for Email and Password
    $rules = array(
      'femail' => 'required|email', // make sure the email is an actual email
      'fpwd' => 'required|alphaNum|min:8');
      // password has to be greater than 3 characters and can only be alphanumeric and);
      // checking all field
      $validator = Validator::make(Input::all() , $rules);
      // if the validator fails, redirect back to the form
      if ($validator->fails())
        {
        return Redirect::to('facultylogin')->withErrors($validator) // send back all errors to the login form
        ->withInput(Input::except('fpwd')); // send back the input (not the password) so that we can repopulate the form
        }
        else
        {
        // create our user data for the authentication
        $userdata = array(
          'femail' => Input::get('femail') ,
          'fpwd' => Input::get('fpwd')
        );
        // attempt to do the login
        if (Auth::attempt($userdata))
          {
            return 'Login Successful';
          }
          else
          {
            return 'Login UnSuccessful';
          }
        }
      }


}
