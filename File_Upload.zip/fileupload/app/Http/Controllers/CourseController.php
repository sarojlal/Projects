<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Course;

class CourseController extends Controller
{
    public function insert(Request $request){
        $this->validate($request,[
            'cname' => 'required'
        ]);
        //return 'Validation Pass';
        $courses=new Course;
        $courses->cname = $request->input('cname');
        $courses->save();
        //return redirect('/viewfaculties')->with('info','Data Inserted successfully');
        return 'Data Inserted';
    }
    public function view(){
        $course = Course::all();
        return view('viewcourses',['courses' => $course]);
    }
    public function update($c_id){
        $course = Course::find($c_id);
        return view('updatecourse',['courses' => $course]);
    }
    public function edit(Request $request, $c_id){
        /*$profiles = prof::find($id);
        return view('update',['profs' => $profiles]);*/
        $data = array(
            'cname' => $request->input('cname')
        );
        Course::where('c_id',$c_id)-> update($data);
        return redirect('/viewcourses')->with('info','Data Updated successfully');
    }
    public function delete($id){
        Course::where('c_id',$id) -> delete();
        return redirect('/viewcourses')->with('info','Data Deleted successfully');
    }
}
