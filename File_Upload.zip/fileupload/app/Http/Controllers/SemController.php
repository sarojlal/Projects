<?php

namespace App\Http\Controllers;
use App\Course;
use App\Sem;

use Illuminate\Http\Request;

class SemController extends Controller
{
    public function home(){
        $course = Course::all();
        return view('addsem',['courses' => $course]);
    }
    public function view(){
        $course = Course::all();
		$sem = Sem::all();
        return view('viewsem',['courses' => $course,'sems' => $sem]);
    }
    public function insert(Request $request){
        $this->validate($request,[
            'sem' => 'required',
            'c_id' => 'required'
        ]);
        //return 'Validation Pass';
        
        $sems=new Sem;
        $sems->c_id = $request->input('c_id');
        $sems->sem = $request->input('sem');
        $sems->save();
        return redirect('/viewsem')->with('info','Data Inserted successfully');
    }
    public function update($sem_id){
        $course = Course::all();
        $sem = Sem::find($sem_id);
        return view('updatesem',['courses' => $course,'sems' => $sem]);
    }
    public function edit(Request $request, $sem_id){
        /*$profiles = prof::find($id);
        return view('update',['profs' => $profiles]);*/
        $data = array(
            'c_id' => $request->input('course'),
            'sem' => $request->input('sem'),
        );
        Sem::where('sem_id',$sem_id)-> update($data);
        return redirect('/viewsem')->with('info','Data Updated successfully');
    }
    public function delete($id){
        Sem::where('sem_id',$id) -> delete();
        return redirect('/viewsem')->with('info','Data Deleted successfully');
    }
}
