<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class APIController extends Controller
{
    public function index()
    {
        $countries = DB::table("courses")->lists("cname","c_id");
        return view('index',compact('courses'));
    }
    public function getStateList(Request $request)
    {
        $states = DB::table("sem")
                    ->where("sem_id",$request->country_id)
                    ->lists("sem","sem_id");
        return response()->json($states);
    }
    // public function getCityList(Request $request)
    // {
    //     $cities = DB::table("cities")
    //                 ->where("state_id",$request->state_id)
    //                 ->lists("name","id");
    //     return response()->json($cities);
    // }
}
