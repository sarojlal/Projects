<?php

namespace App\Http\Controllers\auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Faculty;
use App\Student;

class FacultyLoginController extends Controller
{
    // public function __construct(){
    //     $this->middleware('guest:faculty');
    // }
    public function facultylogin(Request $request){
        $this->validate($request,[
            'femail' => 'required|email',
            'password' =>  'required|min:8'
        ]);
        //$name=\DB::table('faculties');
        $request->session()->put('user',$request->input('femail'));
        $request->session()->get('user');
        if(Auth::guard('faculty')->attempt(['femail' => $request->femail, 'password' => $request->password],$request->remember)){
            // return 'Login Successful';
            return redirect('/viewfaculties')->with('info',$request->session()->get('user'));
        }
        else{
            return redirect('/facultylogin')->with('info','Error!! Invalid Credentials!!');
        }
    }
    public function multilogin(Request $request){
        $this->validate($request,[
            'femail' => 'required|email',
            'password' =>  'required'
        ]);
        // $id=Auth::guard('faculty')->user()->f_id;
        // $faculty = Faculty::find($f_id);
        if(Auth::guard('faculty')->attempt(['femail' => $request->femail, 'password' => $request->password],$request->remember)){
            // return 'Login Successful';
            // $user = Auth::user();
            // $id=Auth::guard('faculty')::fname;

            return redirect('/viewuploads')->with('info','Faculty Login Successful');
        }
        else if(Auth::guard('student')->attempt(['semail' => $request->femail, 'password' => $request->password],$request->remember)){
            // return 'Login Successful';
            return redirect('/viewfiles')->with('info','Student Login Successful');
        }
        else if(Auth::guard('admin')->attempt(['email' => $request->femail, 'password' => $request->password],$request->remember)){
            // return 'Login Successful';
            return redirect('/viewfaculties')->with('info','Admin Login Successful');
        }
        else{
            return redirect('/')->with('info','Error!! Invalid Credentials!!');
        }
    }

}
