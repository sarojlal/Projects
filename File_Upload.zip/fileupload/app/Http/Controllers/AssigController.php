<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File as LaraFile;
use App\fassignment;
use App\StudAssig;
use App\uploads;
use App\Faculty;
use App\Course;
use App\Student;
use App\Sem;
use App\marks;
use Auth;
use DB;

class AssigController extends Controller
{
    public function view(){
        $uploads = uploads::all();
        $assigs = fassignment::all();
        $students = Student::all();
        $courses = Course::all();
        $sems = Sem::all();
        $faculties = Faculty::all();
        //return view('viewfiles',['faculties' => $faculty,'students' => $student , 'courses' => $course , 'sems' => $sem,'uploads' => $upload]);
        return view('viewassignments',compact('assigs','upload_data','uploads','students','courses','sems','faculties'));
    }
    public function index()
    {
        // return view('fileupload');
        $fassignment = fassignment::all();
        $upload = uploads::all();
        $faculty = Faculty::all();
        $course = Course::all();
        $sem = Sem::all();
        $q1 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=c.c_id && c.c_id =1");
        $q2 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=c.c_id && c.c_id =2");
        return view('fassign-upload',['assigs' => $fassignment ,'uploades' => $upload,'faculties' => $faculty ,'courses' => $course , 'sems' => $sem,'qry1' => $q1 ,'qry2' => $q2]);
    }
    public function store(Request $request)
    {
        $id=Auth::guard('faculty')->user()->f_id;
        // dd($request);
        $this->validate($request,[
            'uploads' => 'required',
            'desc' => 'required',
            'course' => 'required',
            'sem' => 'required',
            'class' => 'required|max:2'
        ]);
        
        if($file = $request->file('uploads')){
            
            $name = $file->getClientOriginalName();
            if($file->move('assignment',$name)){
                $upload = new fassignment;
                $upload->document = $name;
                $upload->desc = $request->input('desc');
                $upload->f_id = $id;
                $upload->course = $request->input('course');
                $upload->sem_id = $request->input('sem');
                $upload->class = $request->input('class');
                $upload->save();
                return redirect('/viewassignments')->with('info','Assignment Uploaded Successfully!!');
            };

        }
        else{
            return redirect('/fassign-upload')->with('info','Assignment was not Uploaded !!');
        }

    }
    public function delete($assig_id)
    {

        $upload = fassignment::find($assig_id);
        $image = \DB::table('fassignment')->where('assig_id', $assig_id)->first();
        $file = $upload->document;
        $filename = public_path().'/assignment/'.$file;
        \File::delete($filename);
        uploads::where('assig_id',$assig_id) -> delete();


        return redirect('/viewassignments')->with('info','Assignment Deleted Successfully!!');
    }
    public function viewsub($assig_id)
    {
        $uploads = uploads::all();
        $assigs = fassignment::all();
        $students = Student::all();
        $courses = Course::all();
        $sems = Sem::all();
        $faculties = Faculty::all();
        $studassigs = StudAssig::findMany($assig_id);

        return view('viewsubmissions',compact('studassigs','assigs','students'));
    }

    public function submitmarks(Request $request){
        $id=Auth::guard('faculty')->user()->f_id;
        $this->validate($request,[
            'assig_id' => 'required',
            'assig_name' => 'required',
            'stud_id' => 'required',
            'marks' => 'required',
        ]);

                $marks = new marks;
                $marks->assig_id = $request->input('assig_id');
                $marks->assig_name = $request->input('assig_name');
                $marks->stud_id = $request->input('stud_id');
                $marks->f_id = $id;
                $marks->marks = $request->input('marks');
                $marks->save();
                return redirect('/viewassignments')->with('info','Marks Submitted Successfully!!');

    }

}
