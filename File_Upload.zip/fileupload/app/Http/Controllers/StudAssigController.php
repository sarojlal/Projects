<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\File as LaraFile;

use Illuminate\Http\Request;
use App\fassignment;
use App\StudAssig;
use App\uploads;
use App\Faculty;
use App\Course;
use App\Student;
use App\Sem;
use App\marks;
use Auth;
use DB;

class StudAssigController extends Controller
{
    public function view(){
        $stud_sem =  Auth::guard('student')->user()->sid;
        $uploads = uploads::all();
        $assigs = fassignment::all();
        $students = Student::all();
        $courses = Course::all();
        $sems = Sem::all();
        $faculties = Faculty::all();
        //return view('viewfiles',['faculties' => $faculty,'students' => $student , 'courses' => $course , 'sems' => $sem,'uploads' => $upload]);
        return view('stud_assig_upload',compact('assigs','students','faculties','stud_sem'));
    }

    public function viewmarks(){
        $sid = Auth::guard('student')->user()->sid;
        $uploads = uploads::all();
        $assigs = fassignment::all();
        $students = Student::all();
        $courses = Course::all();
        $sems = Sem::all();
        $marks = marks::all();
        $faculties = Faculty::all();
        //return view('viewfiles',['faculties' => $faculty,'students' => $student , 'courses' => $course , 'sems' => $sem,'uploads' => $upload]);
        return view('viewmarks',compact('marks','assigs','students','faculties','stud_sem','sid'));
    }
    
    public function store(Request $request)
    {
        $id=Auth::guard('student')->user()->sid;
        // dd($request);
        $this->validate($request,[
            'assignment' => 'required',
            'ass_id' => 'required',
            'fid' => 'required',
        ]);
        
        if($file = $request->file('assignment')){
            
            $name = $file->getClientOriginalName();
            if($file->move('stud-assignment',$name)){
                $upload = new StudAssig;
                $upload->assignment = $name;
                $upload->ass_id = $request->input('ass_id');
                $upload->fid = $request->input('fid');
                $upload->stud_id = $id;
                $upload->save();
                return redirect('/viewfiles')->with('info','Assignment Submited Successfully!!');
            };

        }
        else{
            return redirect('/viewfiles')->with('info','File was not Uploaded !!');
        }

    }

}
