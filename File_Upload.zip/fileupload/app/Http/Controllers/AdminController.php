<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Admin;

class AdminController extends Controller
{
    public function insert(Request $request){
        $this->validate($request,[
            'name' => 'required',
            'email' => 'required',
            'password' => 'required'
        ]);
        //return 'Validation Pass';
        $admins=new Admin;
        $admins->name = $request->input('name');
        $admins->email = $request->input('email');
        $admins->password = $request->input('password');
        $admins->save();
        return redirect('/')->with('info','Data Inserted successfully');
        // return 'Data Inserted';
    }
}
