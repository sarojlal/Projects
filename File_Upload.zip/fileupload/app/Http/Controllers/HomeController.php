<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function insert(Request $request){
        #$faculty = Faculty::all();
        $this->validate($request,[
            'name' => 'required',
            'email' => 'required',
            'password' => 'required'
        ]);
        //return 'Validation Pass';
        $faculties=new User;
        $faculties->name = $request->input('name');
        $faculties->email = $request->input('email');
        $faculties->password = bcrypt($request->input('password'));
        $faculties->save();
        return redirect('/viewfaculties')->with('info','Data Inserted successfully');
    }

}
