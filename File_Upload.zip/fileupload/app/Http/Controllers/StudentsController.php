<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use App\Course;
use App\Sem;
use Illuminate\Contracts\Auth\Authenticatable;
use Auth;
use Redirect;
use Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use DB;


class StudentsController extends Controller
{
    public function show(){
        $course = Course::all();
        $sem = Sem::all();
        //$q1 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=$cid && c.c_id =$cid");
        return view('/registerstud',['courses' => $course, 'sems' => $sem ]);
    }
    public function register(){
        $course = Course::all();
        $sem = Sem::all();
        $q1 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=c.c_id && c.c_id =1");
        $q2 = DB::select("SELECT * FROM sems s,courses c  WHERE s.c_id=c.c_id && c.c_id =2");
        return view('/registerstud',['courses' => $course, 'sems' => $sem ,'qry1' => $q1 ,'qry2' => $q2]);
        
    }
    public function rawquery(){
        $q1 = DB::select("SELECT * FROM `sems` s,courses c  WHERE s.c_id=c.c_id && c.c_id =1");
    }
    public function home(){
        $student = Student::all();
        $course = Course::all();
        $sem = Sem::all();
        return view('viewstudents',['students' => $student , 'courses' => $course , 'sems' => $sem]);
    }
    public function insertstud(Request $request){
        #$faculty = Faculty::all();
        
        $this->validate($request,[
            'enroll_no' => 'required|max:12',
            'sname' => 'required',
            'semail' => 'required|email|max:255',
            'spwd' => 'required|min:8',
            'course' => 'required',
            'sem' => 'required',
            'class' => 'required'
        ]);
        //return 'Validation Pass';
        $students=new Student;
        
        $students->enroll_no = $request->input('enroll_no');
        $students->sname = $request->input('sname');
        $students->semail = $request->input('semail');
        $students->password = bcrypt($request->input('spwd'));
        $students->course = $request->input('course');
        $students->sem = $request->input('sem');
        $students->class = $request->input('class');
        $students->save();
        return 'Successful';
        //return view('/view',['faculties' => $faculty]);
    }
    public function update($sid){
        $student = Student::find($sid);
        $course = Course::all();
        return view('updatestud',['students' => $student, 'courses' => $course]);
    }
    public function edit(Request $request, $sid){
        /*$profiles = prof::find($id);
        return view('update',['profs' => $profiles]);*/
        $data = array(
            'sname' => $request->input('sname'),
            'semail' => $request->input('semail'),
            'password' => $request->input('spwd'),
            'course' => $request->input('course'),
            'sem' => $request->input('sem'),
            'class' => $request->input('class'),
        );
        Student::where('sid',$sid)-> update($data);
        return redirect('/viewstudents')->with('info','Data Updated successfully');
    }
    public function delete($id){
        Student::where('sid',$id) -> delete();
        return redirect('/viewstudents')->with('info','Data Deleted successfully');
    }
}
