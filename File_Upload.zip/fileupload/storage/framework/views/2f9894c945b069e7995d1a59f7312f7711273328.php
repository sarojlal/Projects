<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(session('info')): ?>
    <div class="col-mg-6 alert alert-success">
    <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Password</th>
    </tr>
  </thead>
  <tbody>
    <?php if(count($faculties) > 0): ?>
        <?php $__currentLoopData = $faculties -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($faculty -> f_id); ?></td>
            <td><?php echo e($faculty -> fname); ?></td>
            <td><?php echo e($faculty -> femail); ?></td>
            <td><?php echo e($faculty -> fpwd); ?></td>
            <td>
                <a href="<?php echo e(url('/login')); ?>" class="label label-primary">Read</a>
                <a href='<?php echo e(url("/update/{$faculty->f_id}")); ?>' class="label label-success">Update</a>
                <a href='<?php echo e(url("/delete/{$faculty->f_id}")); ?>' class="label label-danger">Delete</a>
            </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </tbody>
</table>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\fileupload\resources\views/viewfaculty.blade.php ENDPATH**/ ?>