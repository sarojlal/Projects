<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>DataTables </h2>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
            <li class="breadcrumb-item"> <a>Tables</a> </li>
            <li class="breadcrumb-item active"> <strong>DataTables</strong> </li>
          </ol>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                <?php if(session('info')): ?>
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    <?php echo e(session('info')); ?>

                  </div>
                  <?php endif; ?>
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                      <thead>
                        <tr>
                          <th>Faculty ID</th>
                          <th>Faculty Name</th>
                          <th>Faculty Email</th>
                          <th>Faculty Password</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>Faculty ID</th>
                          <th>Faculty Name</th>
                          <th>Faculty Email</th>
                          <th>Faculty Password</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                      <?php if(count($faculties) > 0): ?>
                        <?php $__currentLoopData = $faculties -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($faculty -> f_id); ?></td>
                            <td><?php echo e($faculty -> fname); ?></td>
                            <td><?php echo e($faculty -> femail); ?></td>
                            <td><?php echo e($faculty -> password); ?></td>
                            <td>
                                <a href='<?php echo e(url("/update/{$faculty->f_id}")); ?>' class="green btn btn-outline btn-xs"><i class="fa fa-pencil"></i></a>
                                <a href='<?php echo e(url("/delete/{$faculty->f_id}")); ?>' class="red btn btn-outline btn-xs"><i class="fa fa-trash"></i></a>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fileupload\resources\views/viewfaculties.blade.php ENDPATH**/ ?>