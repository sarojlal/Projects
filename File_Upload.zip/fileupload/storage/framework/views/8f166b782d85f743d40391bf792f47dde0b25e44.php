<footer id="footer" class="text text-center">
        <p>Copyright</p>
    </footer>
<?php /**PATH C:\xampp\htdocs\fileupload\resources\views/inc/footer.blade.php ENDPATH**/ ?>