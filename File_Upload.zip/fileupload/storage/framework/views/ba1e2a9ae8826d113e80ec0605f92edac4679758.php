<?php echo $__env->make('adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Semesters </h2>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"> <a href="<?php echo e(url('/viewfaculties')); ?>">Home</a> </li>
            <li class="breadcrumb-item"> <a>Tables</a> </li>
            <li class="breadcrumb-item active"> <strong>View Semesters</strong> </li>
          </ol>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                <?php if(session('info')): ?>
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    <?php echo e(session('info')); ?>

                  </div>
                  <?php endif; ?>
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                      <thead>
                        <tr>
						              <th>Sem ID</th>
                          <th>Course</th>
                          <th>Semester</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
						              <th>Sem ID</th>
                          <th>Course</th>
                          <th>Semester</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                      <?php if(count($sems) > 0): ?>
                        <?php $__currentLoopData = $sems -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($sem -> sem_id); ?></td>
                            <td>
                            <?php if(count($courses) > 0): ?>
                                <?php $__currentLoopData = $courses -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($sem->c_id === $course->c_id): ?>
                                        <?php echo e($course->cname); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </td>
                            
							<td><?php echo e($sem -> sem); ?></td>
                            <td>
                                <a href='<?php echo e(url("/updatesem/{$sem->sem_id}")); ?>' class="green btn btn-outline btn-xs"><i class="fa fa-pencil"></i></a>
                                <a href='<?php echo e(url("/deletesem/{$sem->sem_id}")); ?>' class="red btn btn-outline btn-xs"><i class="fa fa-trash"></i></a>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/viewsem.blade.php ENDPATH**/ ?>