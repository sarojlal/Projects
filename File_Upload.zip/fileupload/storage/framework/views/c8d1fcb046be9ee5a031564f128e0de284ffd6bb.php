<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/table_datatables.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:48:59 GMT -->
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>The Wolf</title>
<!-- dataTables -->
<link href="<?php echo e(url('/css/buttons.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('/css/responsive.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('/css/fixedHeader.dataTables.min.css')); ?>" rel="stylesheet">
<!-- Bootstrap -->
<link href="<?php echo e(url('/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('/css/jasny-bootstrap.min.css')); ?>">
<!-- slimscroll -->
<link href="<?php echo e(url('/css/jquery.slimscroll.css')); ?>" rel="stylesheet">
<!-- Fontes -->
<link href="<?php echo e(url('/css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(url('/css/glyphicons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('/css/simple-line-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('/css/buttons.css')); ?>" rel="stylesheet">
<!-- animate css -->
<link href="<?php echo e(url('/css/animate.css')); ?>" rel="stylesheet">
<!-- The Wolf main css -->
<link href="<?php echo e(url('/css/main.css')); ?>" rel="stylesheet">
<!-- theme css -->
<link href="<?php echo e(url('/css/theme.css')); ?>" rel="stylesheet">
<!-- media css for responsive  -->
<link href="<?php echo e(url('/css/main.media.css')); ?>" rel="stylesheet">

<!-- demo  -->
<link href="<?php echo e(url('/css/appdemo.css')); ?>" rel="stylesheet">
<script src="<?php echo e(url('js/vendor/jquery.min.js')); ?>"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js')}}"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js')}}"></script>
    <![endif]-->

<!-- Script to hide/show -->

<!-- Script complete-->


</head>
<body class="page-header-fixed page-sidebar-menu-border  page-sidebar-fixed ">
<div class="page-header navbar aqua-bg fixed-top">
  <!-- BEGIN HEADER INNER -->
  <div class="page-header-inner ">
    <!-- BEGIN LOGO -->
    <div class="page-logo">
				<a href="index.html"> <img class="logo-default" alt="logo" src="<?php echo e(url('/images/logo.png')); ?>"> </a>
			</div>
			<div class="sidebar-close-logo">
				<a href="index.html"> <img class="logo-default" alt="logo" src="<?php echo e(url('/images/sidebar-close-logo.png')); ?>"> </a>
			</div>
    <!-- END LOGO -->
    <div class="library-menu"> <span class="one">-</span> <span class="two">-</span> <span class="three">-</span> </div>
<a class="mobile-sub-link hidden-md-up"><i class="fa fa-ellipsis-v"></i></a>
    <!-- BEGIN TOP NAVIGATION MENU -->
    <div class="top-menu">
    <div class="hor-menu hidden-sm-down">
        <ul class="nav">
            <li class="nav-item"> <a onclick="toggleFullScreen()" href="javascript:;" class="nav-link fullscreen"><span class="glyphicon glyphicon-fullscreen"> </span></a>
            </li>
        </ul>
    </div>

    
      <ul class="nav navbar-nav pull-right hidden-sm-down">
        <!-- <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle count-info" > <i class="fa fa-envelope"></i> <span class="badge badge-info">6</span> </a> -->
          <ul class="dropdown-menu dropdown-messages menuBig">
            <li>
              <div class="dropdown-messages-box"> <a class="pull-left" href="profile.html"> <img src="<?php echo e(url('/images/teem/a7.jpg')); ?>" class="rounded-circle" alt="image"> </a>
                <div class="media-body"> <small class="pull-right">46h ago</small> <strong>Mike Loreipsum</strong> started following <strong>Olivia Wenscombe</strong>. <br>
                  <small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small> </div>
              </div>
            </li>
            <li class="divider"></li>
            <li>
              <div class="dropdown-messages-box"> <a class="pull-left" href="profile.html"> <img src="<?php echo e(url('/images/teem/a4.jpg')); ?>" class="rounded-circle" alt="image"> </a>
                <div class="media-body "> <small class="pull-right text-navy">5h ago</small> <strong>Alex Smith </strong> started following <strong>Olivia Wenscombe</strong>. <br>
                  <small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small> </div>
              </div>
            </li>
            <li class="divider"></li>
            <li>
              <div class="dropdown-messages-box"> <a class="pull-left" href="profile.html"> <img src="<?php echo e(url('/images/teem/a3.jpg')); ?>" class="rounded-circle" alt="image"> </a>
                <div class="media-body "> <small class="pull-right">23h ago</small> <strong>Olivia Wenscombe</strong> love <strong>Sophie </strong>. <br>
                  <small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small> </div>
              </div>
            </li>
            <li class="divider"></li>
            <li>
              <div class="text-center link-block"> <a href="mailbox.html"> <i class="fa fa-envelope"></i> <strong>Read All Messages</strong> </a> </div>
            </li>
          </ul>
        </li>
        <li class="dropdown">
        <a data-toggle="dropdown" class="dropdown-toggle count-info" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <i class="fa fa-sign-out"></i>
                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>

          </li>
        <!-- START USER LOGIN DROPDOWN -->
<li class="dropdown dropdown-user"> <a data-close-others="true" data-hover="dropdown" data-toggle="dropdown"  class="dropdown-toggle" href="javascript:;"> <img src="<?php echo e(url('/images/teem/a10.jpg')); ?>" class="rounded-circle" alt=""> <span class="username username-hide-on-mobile"> <?php echo e(Auth::guard('admin')->user()->name); ?> </span> <i class="fa fa-angle-down"></i> </a>
          <ul class="dropdown-menu dropdown-menu-default">
            <li> <a href="profile.html"> <i class="icon-user"></i> My Profile </a></li>
<li>
<a href="profile_2.html"> <i class="icon-user"></i> Profile-2 </a> </li>
            <li> <a href="calendar.html"> <i class="icon-calendar"></i> My Calendar </a> </li>
            <li> <a href="mailbox.html"> <i class="icon-envelope-open"></i> My Inbox <span class="badge badge-danger"> 3 </span> </a> </li>
            <li> <a href="dashboard2.html"> <i class="icon-rocket"></i> My Tasks <span class="badge badge-success"> 7 </span> </a> </li>
            <li class="divider"> </li>
            <li> <a href="lockscreen.html"> <i class="icon-lock"></i> Lock Screen </a> </li>
            <li> <a href="login.html"> <i class="icon-key"></i> Log Out </a> </li>
          </ul>
        </li>
        <!-- END USER LOGIN DROPDOWN -->
      </ul>
    </div>
    <!-- END TOP NAVIGATION MENU -->
  </div>
  <!-- END HEADER INNER -->
</div>
<div class="clearfix"> </div>
<div class="page-container">
  <!-- Start page sidebar wrapper -->
  <div class="page-sidebar-wrapper">
    <div class="page-sidebar sidebar-light">
      <ul class="page-sidebar-menu  page-header-fixed ">
        
        <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-user"></i> <span class="title">Faculties</span> <span class="arrow"></span> </a>
          <ul class="sub-menu">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/registerfacul')); ?>"><i class="icon-user"></i>Add Faculty</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/viewfaculties')); ?>"><i class="fa fa-table"></i>View Faculties</a></li>
          </ul>
        </li>
        <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-user"></i> <span class="title">Bulk Upload</span> <span class="arrow"></span> </a>
          <ul class="sub-menu">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/bulkupload')); ?>"><i class="icon-user"></i>Add Faculties</a></li>
            <!-- <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/viewuploads')); ?>"><i class="fa fa-table"></i>View Uploads</a></li> -->
          </ul>
        </li>
        <!-- <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-user"></i> <span class="title">Assignment</span> <span class="arrow"></span> </a>
          <ul class="sub-menu">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/faculty-assignment')); ?>"><i class="icon-user"></i>Add Assignment</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/viewuploads')); ?>"><i class="fa fa-table"></i>View Assignments</a></li>
          </ul>
        </li> -->
        <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-user"></i> <span class="title">Courses</span> <span class="arrow"></span> </a>
          <ul class="sub-menu">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/course')); ?>"><i class="icon-user"></i>Add Course</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/viewcourses')); ?>"><i class="fa fa-table"></i>View Courses</a></li>
          </ul>
        </li>
		<li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-user"></i> <span class="title">Semester</span> <span class="arrow"></span> </a>
          <ul class="sub-menu">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/sem')); ?>"><i class="icon-user"></i>Add Sem</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/viewsem')); ?>"><i class="fa fa-table"></i>View Sem</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/adminheader.blade.php ENDPATH**/ ?>