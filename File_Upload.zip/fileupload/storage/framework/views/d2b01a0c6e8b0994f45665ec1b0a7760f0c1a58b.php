Hey <?php echo e($user); ?>,you are getting this email because you requested reset password in our portal.<br>
<p>
Reset Password Link:<a href="<?php echo e($name); ?>"><?php echo e($name); ?></a>
</p><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/email_link.blade.php ENDPATH**/ ?>