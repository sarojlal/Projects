<?php echo $__env->make('student_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2> Student Assignment Upload </h2>
        </div>
        <div class="col-lg-12"> 
        <div class="form-group row">
            
        </div>
      </div>
      
                    <!-- Script to hide/show -->
                    <script type="text/javascript">
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "-1") {
                                        $("#1").hide();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                    
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "1") {
                                        $("#1").show();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                        
                        $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "2") {
                                        $("#2").show();
                              $("#1").hide();
                            } 
                                        
                          });
                            });
                        </script>
                    <!-- Script complete-->
      <!-- File Upload Starts -->
      <form action="<?php echo e(url('/studassig-store')); ?>" method="POST" enctype="multipart/form-data" class="m-t">
            <?php echo csrf_field(); ?>
                    <!-- <div class="form-group"> -->
                    <!-- <label class="custom-file">
                        <input type="file" name="uploads" id="file" class="custom-file-input">
                        <span class="custom-file-control"></span>
                    </label> -->
                    
                    <div class="form-group row">
                        <label for="assignment">Choose File</label>
                        <input class="form-control" type="file" name="assignment" id="assignment" >
                        
                    </div>
                    
                    <!-- Elements of different models -->
                    <div class="form-group row" id="formgroup">
                    <label for="course">Select Assignment</label>
                      <select name="ass_id" class="form-control" id="ass_id">
                      <option value="-1" selected disabled>--Select Assignment--</option>
                      <?php if(count($assigs) > 0): ?>
                        <?php $__currentLoopData = $assigs -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($students[0]->course === $assig->course && $students[0]->sem === $assig->sem_id && $students[0]->class === $assig->class ): ?>
                        <option value="<?php echo e($assig->assig_id); ?>" >
                            <?php echo e($assig->document); ?>

                        </option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                      </select>
                    </div>

                    <div class="form-group row" id="formgroup">
                    <label for="course">Select Faculty</label>
                      <select name="fid" class="form-control" id="fid">
                      <option value="-1" selected disabled>--Select Faculty--</option>
                      <?php if(count($faculties) > 0): ?>
                          <?php $__currentLoopData = $faculties -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($faculty->f_id); ?>">
                              <?php echo e($faculty->fname); ?>

                          </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </select>
                    </div>
                    <!-- <div class="form-group">
                      <input type="text" required="" placeholder="Sem" name="sem" id="sem" class="form-control">
                    </div> -->
                    <!-- Elements of different models Ends -->

                    <div class="form-group row">  
                  <button class="btn  mb-0 aqua" type="submit">Submit</button>
                <div/>
                </div>
            </form>
             <!-- File upload completes -->
      
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/stud_assig_upload.blade.php ENDPATH**/ ?>