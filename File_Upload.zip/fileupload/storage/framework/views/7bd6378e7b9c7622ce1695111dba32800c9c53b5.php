<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>The Wolf</title>
<!-- Bootstrap -->
<link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- icheck -->
<link href="<?php echo e(url('css/skins/all.css')); ?>" rel="stylesheet">
<!-- slimscroll -->
<link href="<?php echo e(url('css/jquery.slimscroll.css')); ?>" rel="stylesheet">
<!-- Fontes -->
<link href="<?php echo e(url('css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(url('css/glyphicons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('css/simple-line-icons.css')); ?>" rel="stylesheet">
<!-- all buttons css -->
<link href="<?php echo e(url('css/buttons.css')); ?>" rel="stylesheet">
<!-- animate css -->
<link href="<?php echo e(url('css/animate.css')); ?>" rel="stylesheet">
<!-- The Wolf main css -->
<link href="<?php echo e(url('css/main.css')); ?>" rel="stylesheet">
<!-- theme css -->
<link href="<?php echo e(url('css/theme.css')); ?>" rel="stylesheet">
<!-- media css for responsive  -->
<link href="<?php echo e(url('css/main.media.css')); ?>" rel="stylesheet">

<!-- demo  -->
<link href="<?php echo e(url('css/appdemo.css')); ?>" rel="stylesheet">
<!--[if lt IE 9]> <script src="http://html5shim.googlecode.com/svn/trunk/html5.js')}}"></script> <![endif]-->
<!--[if lt IE 9]> <script src="dist/html5shiv.js')}}"></script> <![endif]-->
</head>
<body class="login">
<div class="middle-box text-center loginscreen   ">
  <div class="widgets-container">
    <div>
      <h1 class="logo-name">WOLF</h1>
    </div>
    <h3>Register to The Wolf</h3>
    <p>Create account to see it in action.</p>
    <form action="<?php echo e(url('/insertfacul')); ?>" method="POST" class="m-t">
    <?php echo csrf_field(); ?>
      <div class="form-group">
        <input type="text" required="" placeholder="Name" name="fname" id="fname" class="form-control">
      </div>
      <div class="form-group">
        <input type="email" required="" placeholder="Email" name="femail" id="femail" class="form-control">
      </div>
      <div class="form-group">
        <input type="password" required="" placeholder="Password" name="fpwd" id="fpwd" class="form-control">
      </div>
      <div class="form-group">
        <div class="i-checks">
          <input type="checkbox" class="iCheck" indeterminate="true">
          Agree the terms and policy </div>
      </div>
      <button class="btn aqua block full-width m-b" type="submit">Register</button>
      <p class="text-muted text-center"><small>Already have an account?</small></p>
      <a href="<?php echo e(url('/')); ?>" class="btn btn-sm btn-white btn-block">Login</a>
    </form>
    <p class="top15"> <small>The Wolf is easy to use and customize &copy; 2016-2017</small> </p>
  </div>
</div>
<!-- demo  -->
<script src="<?php echo e(url('js/appdemo.js')); ?>"></script>

<!-- start theme config -->
<div class="theme-config hidden-lg-down">
    <div class="theme-config-box">
        <div class="spin-icon"> <i class="fa fa-cogs fa-spin"></i> </div>
        <div class="skin-setttings">
            <div class="title">Configuration</div>
            <div class="setings-item"> <span> Collapse menu </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="collapsemenu" class="onoffswitch-checkbox" id="collapsemenu" type="checkbox">
                        <label class="onoffswitch-label" for="collapsemenu">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Fixed sidebar </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedsidebar" class="onoffswitch-checkbox" id="fixedsidebar" type="checkbox">
                        <label class="onoffswitch-label" for="fixedsidebar">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Header Fixed </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="headerfixed" class="onoffswitch-checkbox" id="headerfixed" type="checkbox" checked>
                        <label class="onoffswitch-label" for="headerfixed">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="setings-item"> <span> Fixed footer </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedfooter" class="onoffswitch-checkbox" id="fixedfooter" type="checkbox">
                        <label class="onoffswitch-label" for="fixedfooter">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="title">Navigation Color</div>


            <!-- Nav tabs -->
            <ul class="nav nav-tabs nav-justified" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Semi Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Semi Dark</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab">Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Dark</a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active semi-light" id="home" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>

                </div>
                <div class="tab-pane semi-dark" id="profile" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
                <div class="tab-pane light" id="messages" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>

                    </div>
                </div>
                <div class="tab-pane dark" id="settings" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
            </div>

            <div class="title">Sidebar Options</div>

            <div class="text-center m-3">
                <div class="btn-group">
                    <button class="btn btn-white sidebar-Light" type="button">Light</button>
                    <button class="btn dark sidebar-Dark" type="button">Dark</button>
                </div>
            </div>

            <div class="setings-item gohome "> <span class="skin-name"> <a href="../../index.html"> Go to Lending Page </a> </span> </div>
        </div>
    </div>
</div>
<!-- end theme config -->
</body>
<!-- Go top -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(url('js/vendor/jquery.min.js')); ?>"></script>
<!-- icheck -->
<script src="<?php echo e(url('js/vendor/icheck.js')); ?>"></script>
<!-- bootstrap js -->
<script src="<?php echo e(url('js/vendor/tether.min.js')); ?>"></script>
<script src="<?php echo e(url('js/vendor/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/vendor/jquery.dataTables.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/vendor/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- pace js -->
<script src="<?php echo e(url('js/vendor/pace/pace.min.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(url('js/main.js')); ?>"></script>
<script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-green',
            });
        });
    </script>

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\fileupload\resources\views/registerfacul.blade.php ENDPATH**/ ?>