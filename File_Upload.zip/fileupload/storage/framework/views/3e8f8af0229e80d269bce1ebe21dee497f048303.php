<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Students</h2>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
            <li class="breadcrumb-item"> <a>Tables</a> </li>
            <li class="breadcrumb-item active"> <strong>View Students</strong> </li>
          </ol>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                <?php if(session('info')): ?>
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    <?php echo e(session('info')); ?>

                  </div>
                  <?php endif; ?>
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                      <thead>
                        <tr>
                          <th>Student ID</th>
                          <th>Student Name</th>
                          <th>Student Email</th>
                          <th>Student Course</th>
                          <th>Student Sem</th>
                          <th>Student Div</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                        <th>Student ID</th>
                          <th>Student Name</th>
                          <th>Student Email</th>
                          <th>Student Course</th>
                          <th>Student Sem</th>
                          <th>Student Div</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                      <?php if(count($students) > 0): ?>
                        <?php $__currentLoopData = $students -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($student -> sid); ?></td>
                            <td><?php echo e($student -> sname); ?></td>
                            <td><?php echo e($student -> semail); ?></td>
                            <td>
                            <?php if(count($courses) > 0): ?>
                                <?php $__currentLoopData = $courses -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($student->course === $course->c_id): ?>
                                        <?php echo e($course->cname); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </td>
                            <td>
                            <?php if(count($sems) > 0): ?>
                                <?php $__currentLoopData = $sems -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($student->sem === $sem->sem_id): ?>
                                        <?php echo e($sem->sem); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </td>
                            <td><?php echo e($student -> class); ?></td>
                            <td>
                                <a href='<?php echo e(url("/updates/{$student->sid}")); ?>' class="green btn btn-outline btn-xs"><i class="fa fa-pencil"></i></a>
                                <a href='<?php echo e(url("/deletes/{$student->sid}")); ?>' class="red btn btn-outline btn-xs"><i class="fa fa-trash"></i></a>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fileupload\resources\views/viewstudents.blade.php ENDPATH**/ ?>