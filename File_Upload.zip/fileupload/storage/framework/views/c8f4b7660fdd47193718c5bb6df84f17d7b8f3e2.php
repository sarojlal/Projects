<?php echo $__env->make('adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2> File Upload </h2>
        </div>
        <div class="col-lg-12"> 
        <div class="form-group row">
            
        </div>
      </div>
      
                    <!-- Script to hide/show -->
                    <script type="text/javascript">
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "-1") {
                                        $("#1").hide();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                    
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "1") {
                                        $("#1").show();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                        
                        $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "2") {
                                        $("#2").show();
                              $("#1").hide();
                            } 
                                        
                          });
                            });
                        </script>
                    <!-- Script complete-->
      <!-- File Upload Starts -->
      <form action="<?php echo e(url('/uploadFile')); ?>" method="POST" enctype="multipart/form-data" class="m-t">
            <?php echo csrf_field(); ?>
                    <div class="form-group">
                    <!-- <label class="custom-file">
                        <input type="file" name="uploads" id="file" class="custom-file-input">
                        <span class="custom-file-control"></span>
                    </label> -->
                    <?php if(Session::has('message')): ?>
                    <p ><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label for="uploads">Choose File for CSV Upload</label>
                        <input class="form-control" type="file" name="uploads" id="uploads" >
                    </div> 
                    <!-- Elements of different models -->
                    <!-- Elements of different models Ends -->
                    
                  <!-- <button class="btn  mb-0 aqua" name="submit" type="submit">Submit</button> -->
                  <input type='submit' class="btn  mb-0 aqua" name='submit' value='Import'>
                </div>
            </form>
             <!-- File upload completes -->
      
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/csv_faculty_upload.blade.php ENDPATH**/ ?>