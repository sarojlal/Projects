<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Submissions</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                <?php if(session('info')): ?>
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    <?php echo e(session('info')); ?>

                  </div>
                  <?php endif; ?>
                  <div class="row">
                  <div class="col-lg-12" >
                  <form method="POST" action='<?php echo e(url("/submitmarks")); ?>'>
                    <?php echo csrf_field(); ?>
                    <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert-heading">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                       <thead>
                        <tr>
                          <th>Assignment ID</th>
                          <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited (Student)</th>
                          <th>Description</th>
                          <th>Student Name</th>
                          <th>Marks</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>Assignment ID</th>
                          <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited (Student)</th>
                          <th>Description</th>
                          <th>Student Name</th>
                          <th>Marks</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                      
                        <?php if(count($studassigs) > 0): ?>
                            <?php $__currentLoopData = $studassigs -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $assigs -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($ass->assig_id == $assig->ass_id): ?>
                                <tr>
                                
                                <td>
                                <input type="hidden" name="assig_id" value="<?php echo e($assig -> ass_id); ?>" />
                                <?php echo e($assig -> ass_id); ?>

                                </td>
                                <td>
                                <input type="hidden" name="assig_name_faculty" value="<?php echo e($ass -> document); ?>" />
                                <?php echo e($ass -> document); ?>

                                </td>
                                <td>
                                <input type="hidden" name="assig_name" value="<?php echo e($assig->assignment); ?>" />
                                <?php echo e($assig->assignment); ?>

                                </td>
                                <td><?php echo e($ass->desc); ?></td>
                                <td>
                                <input type="hidden" name="stud_id" value="<?php echo e($students[0]->sid); ?>" />
                                <?php echo e($students[0]->sname); ?>

                                </td>
                                <td>
                                <input type="number" min=0 max=10 name="marks" placeholder="Marks" style="width:60px;height:20px" />
                                <!-- <a href='<?php echo e(url("/submitmarks")); ?>' class="green btn btn-outline btn-xs"><i class="fa fa-eye"></i>Submit Marks</a> -->
                                <button class="btn btn-primary" type="submit" style="width:30px;height:20px"><i class="fa fa-check"></i></button>
                                </td>
                                <td>
                                    <a href="../stud-assignment/<?php echo e($assig -> assignment); ?>" download="<?php echo e($assig -> assignment); ?>" class="green btn btn-outline btn-xs"><i class="fa fa-download"></i></a>
                                    
                                </td>
                                </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                    </form>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/viewsubmissions.blade.php ENDPATH**/ ?>