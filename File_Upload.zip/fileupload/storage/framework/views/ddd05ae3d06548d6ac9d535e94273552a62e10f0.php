<?php echo $__env->make('student_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Assignments</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                <?php if(session('info')): ?>
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    <?php echo e(session('info')); ?>

                  </div>
                  <?php endif; ?>
                  
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                    <thead>
                        <tr>
                          <th>Assignment ID</th>
                          <th>Assignment Name</th>
                          <th>Description</th>
                          <th>Faculty Name</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                        <th>Assignment ID</th>
                          <th>Assignment Name</th>
                          <th>Description</th>
                          <th>Faculty Name</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php if(count($assigs) > 0): ?>
                        <?php $__currentLoopData = $assigs->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($students[0]->course === $assig->course && $students[0]->sem === $assig->sem_id && $students[0]->class === $assig->class ): ?>

                         <tr>
                         <td><?php echo e($assig->assig_id); ?></td>
                         <td><?php echo e($assig->document); ?></td>
                         <td><?php echo e($assig->desc); ?></td>
                         <td>
                         <?php if(count($faculties) > 0): ?>
                                <?php $__currentLoopData = $faculties -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($faculty->f_id == $assig->f_id): ?>
                                        <?php echo e($faculty->fname); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                         </td>
                                <td>
                                <a href="assignment/<?php echo e($assig -> document); ?>" download="<?php echo e($assig -> document); ?>" class="green btn btn-outline btn-xs"><i class="fa fa-download"></i></a>
                                </td>
                                </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <table>
                 
                      </tbody>
                    </table>
      <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/viewassigs_stud.blade.php ENDPATH**/ ?>