<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2> File Upload </h2>
        </div>
        <div class="col-lg-12"> 
        <div class="form-group row">
            
        </div>
      </div>
      
                    <!-- Script to hide/show -->
                    <script type="text/javascript">
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "-1") {
                                        $("#1").hide();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                    
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "1") {
                                        $("#1").show();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                        
                        $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "2") {
                                        $("#2").show();
                              $("#1").hide();
                            } 
                                        
                          });
                            });
                        </script>
                    <!-- Script complete-->
      <!-- File Upload Starts -->
      <form action="<?php echo e(url('/store')); ?>" method="POST" enctype="multipart/form-data" class="m-t">
            <?php echo csrf_field(); ?>
                    <div class="form-group">
                    <!-- <label class="custom-file">
                        <input type="file" name="uploads" id="file" class="custom-file-input">
                        <span class="custom-file-control"></span>
                    </label> -->
                    <div class="form-group row">
                        <label for="uploads">Choose File</label>
                        <input class="form-control" type="file" name="uploads" id="uploads" >
                        
                    </div>
                    <!-- Elements of different models -->
                    <div class="form-group row" id="formgroup">
                    <label for="course">Select Course</label>
                      <select name="course" class="form-control" id="course">
                      <option value="-1" selected disabled>--Select Course--</option>
                      <?php if(count($courses) > 0): ?>
                          <?php $__currentLoopData = $courses -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($course->c_id); ?>">
                              <?php echo e($course->cname); ?>

                          </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </select>
                    </div>
                    <!-- <div class="form-group">
                      <input type="text" required="" placeholder="Sem" name="sem" id="sem" class="form-control">
                    </div> -->
                    
                    <!-- Continue elements-->
                    <div class="form-group row" style="display:none" id="1">
                      <label for="sem">Select Sem</label>
                      <select name="sem" onchange="" class="form-control">
                      <option value="-1" selected disabled>--Select Sem for MCA--</option>
                      <?php if(count($qry1) > 0): ?>
                              <?php $__currentLoopData = $qry1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($qry->sem_id); ?>" >
                                      <?php echo e($qry->sem); ?>

                                  </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </select>
                    </div>
                    <div class="form-group row" style="display:none" id="2">
                      <label for="sem">Select Sem</label>
                      <select name="sem" onchange="" class="form-control">
                      <option value="-1" selected disabled>--Select Sem for IMCA--</option>
                      <?php if(count($qry2) > 0): ?>
                              <?php $__currentLoopData = $qry2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($q1->sem_id); ?>" >
                                      <?php echo e($q1->sem); ?>

                                  </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </select>
                    </div>
                    

                    
                    <div class="form-group row">
                    <label for="class">Select Division</label>
                      <select name="class" class="form-control">
                          <option value="A">A</option>
                          <option value="B">B</option>
                          <option value="C">C</option>
                      </select>
                    </div>
                    <!-- Elements of different models Ends -->
                    
                  <button class="btn  mb-0 aqua" type="submit">Submit</button>
                
                </div>
            </form>
             <!-- File upload completes -->
      
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fileupload\resources\views/fileupload.blade.php ENDPATH**/ ?>