<?php echo $__env->make('student_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Assignments</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                <?php if(session('info')): ?>
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    <?php echo e(session('info')); ?>

                  </div>
                  <?php endif; ?>
                  
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                    <thead>
                        <tr>
                          <th>Mark ID</th>
                          <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited(Student)</th>
                          <th>Faculty Name</th>
                          <th>Marks</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                        <th>Mark ID</th>
                        <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited(Student)</th>
                          <th>Faculty Name</th>
                          <th>Marks</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php if(count($marks) > 0): ?>
                        <?php $__currentLoopData = $marks->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( $mark->stud_id == Auth::guard('student')->user()->sid ): ?>

                         <tr>
                         <td><?php echo e($mark->mid); ?></td>
                         <td>
                              <?php $__currentLoopData = $assigs->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($assig->assig_id == $mark->assig_id): ?>
                                <?php echo e($assig->document); ?>

                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </td>
                         <td><?php echo e($mark->assig_name); ?></td>
                         <td>
                         <?php if(count($faculties) > 0): ?>
                                <?php $__currentLoopData = $faculties -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($faculty->f_id == $mark->f_id): ?>
                                        <?php echo e($faculty->fname); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                         </td>
                                <td><?php echo e($mark->marks); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <table>
                 
                      </tbody>
                    </table>
      <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_fileupload\fileupload\resources\views/viewmarks.blade.php ENDPATH**/ ?>