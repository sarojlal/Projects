<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>The Wolf</title>
<!-- Bootstrap -->
<link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- icheck -->
<link href="<?php echo e(url('css/skins/all.css')); ?>" rel="stylesheet">
<!-- slimscroll -->
<link href="<?php echo e(url('css/jquery.slimscroll.css')); ?>" rel="stylesheet">
<!-- Fontes -->
<link href="<?php echo e(url('css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(url('css/glyphicons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('css/simple-line-icons.css')); ?>" rel="stylesheet">
<!-- all buttons css -->
<link href="<?php echo e(url('css/buttons.css')); ?>" rel="stylesheet">
<!-- animate css -->
<link href="<?php echo e(url('css/animate.css')); ?>" rel="stylesheet">
<!-- The Wolf main css -->
<link href="<?php echo e(url('css/main.css')); ?>" rel="stylesheet">
<!-- theme css -->
<link href="<?php echo e(url('css/theme.css')); ?>" rel="stylesheet">
<!-- media css for responsive  -->
<link href="<?php echo e(url('css/main.media.css')); ?>" rel="stylesheet">

<!-- demo  -->
<link href="<?php echo e(url('css/appdemo.css')); ?>" rel="stylesheet">
<!--[if lt IE 9]> <script src="http://html5shim.googlecode.com/svn/trunk/html5.js')}}"></script> <![endif]-->
<!--[if lt IE 9]> <script src="dist/html5shiv.js')}}"></script> <![endif]-->
</head>

<body class="page-header-fixed page-sidebar-menu-border  page-sidebar-fixed ">
<div class="page-header navbar aqua-bg fixed-top">
  <!-- BEGIN HEADER INNER -->
  <div class="page-header-inner ">
    <!-- BEGIN LOGO -->
    <div class="page-logo">
				<a href="index.html"> <img class="logo-default" alt="logo" src="<?php echo e(url('/images/logo.png')); ?>"> </a>
			</div>
			<div class="sidebar-close-logo">
				<a href="index.html"> <img class="logo-default" alt="logo" src="<?php echo e(url('/images/sidebar-close-logo.png')); ?>"> </a>
			</div>
    <!-- END LOGO -->
    <div class="library-menu"> <span class="one">-</span> <span class="two">-</span> <span class="three">-</span> </div>
<a class="mobile-sub-link hidden-md-up"><i class="fa fa-ellipsis-v"></i></a>
    <!-- BEGIN TOP NAVIGATION MENU -->
    <div class="top-menu">
    <div class="hor-menu hidden-sm-down">
        <ul class="nav">
            <li class="nav-item"> <a onclick="toggleFullScreen()" href="javascript:;" class="nav-link fullscreen"><span class="glyphicon glyphicon-fullscreen"> </span></a>
            </li>
        </ul>
    </div>

    
      <ul class="nav navbar-nav pull-right hidden-sm-down">
        <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle count-info" > <i class="fa fa-envelope"></i> <span class="badge badge-info">6</span> </a>
          <ul class="dropdown-menu dropdown-messages menuBig">
            <li>
              <div class="dropdown-messages-box"> <a class="pull-left" href="profile.html"> <img src="<?php echo e(url('/images/teem/a7.jpg')); ?>" class="rounded-circle" alt="image"> </a>
                <div class="media-body"> <small class="pull-right">46h ago</small> <strong>Mike Loreipsum</strong> started following <strong>Olivia Wenscombe</strong>. <br>
                  <small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small> </div>
              </div>
            </li>
            <li class="divider"></li>
            <li>
              <div class="dropdown-messages-box"> <a class="pull-left" href="profile.html"> <img src="<?php echo e(url('/images/teem/a4.jpg')); ?>" class="rounded-circle" alt="image"> </a>
                <div class="media-body "> <small class="pull-right text-navy">5h ago</small> <strong> Alex Smith </strong> started following <strong>Olivia Wenscombe</strong>. <br>
                  <small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small> </div>
              </div>
            </li>
            <li class="divider"></li>
            <li>
              <div class="dropdown-messages-box"> <a class="pull-left" href="profile.html"> <img src="<?php echo e(url('/images/teem/a3.jpg')); ?>" class="rounded-circle" alt="image"> </a>
                <div class="media-body "> <small class="pull-right">23h ago</small> <strong>Olivia Wenscombe</strong> love <strong>Sophie </strong>. <br>
                  <small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small> </div>
              </div>
            </li>
            <li class="divider"></li>
            <li>
              <div class="text-center link-block"> <a href="mailbox.html"> <i class="fa fa-envelope"></i> <strong>Read All Messages</strong> </a> </div>
            </li>
          </ul>
        </li>
        <li class="dropdown"> <a href="#" data-toggle="dropdown" class="dropdown-toggle count-info" > <i class="fa fa-bell"></i> <span class="badge badge-primary">8</span> </a>
          <ul class="dropdown-menu dropdown-alerts menuBig">
            <li> <a href="mailbox.html">
              <div> <i class="fa fa-envelope fa-fw"></i> You have 16 messages <span class="pull-right text-muted small">4 minutes ago</span> </div>
              </a> </li>
            <li class="divider"></li>
            <li> <a href="profile.html">
              <div> <i class="fa fa-twitter fa-fw"></i> 3 New Followers <span class="pull-right text-muted small">12 minutes ago</span> </div>
              </a> </li>
            <li class="divider"></li>
            <li> <a href="index.html">
              <div> <i class="fa fa-upload fa-fw"></i> Server Rebooted <span class="pull-right text-muted small">4 minutes ago</span> </div>
              </a> </li>
            <li class="divider"></li>
            <li>
              <div class="text-center link-block"> <a href="mailbox.html"> <strong>See All Alerts</strong> <i class="fa fa-angle-right"></i> </a> </div>
            </li>
          </ul>
        </li>
        <!-- START USER LOGIN DROPDOWN -->
<li class="dropdown dropdown-user"> <a data-close-others="true" data-hover="dropdown" data-toggle="dropdown"  class="dropdown-toggle" href="javascript:;"> <img src="<?php echo e(url('/images/teem/a10.jpg')); ?>" class="rounded-circle" alt=""> <span class="username username-hide-on-mobile"> Susan Wenscombe</span> <i class="fa fa-angle-down"></i> </a>
          <ul class="dropdown-menu dropdown-menu-default">
            <li> <a href="profile.html"> <i class="icon-user"></i> My Profile </a>

</li>
<li>
<a href="profile_2.html"> <i class="icon-user"></i> Profile-2 </a> </li>
            <li> <a href="calendar.html"> <i class="icon-calendar"></i> My Calendar </a> </li>
            <li> <a href="mailbox.html"> <i class="icon-envelope-open"></i> My Inbox <span class="badge badge-danger"> 3 </span> </a> </li>
            <li> <a href="dashboard2.html"> <i class="icon-rocket"></i> My Tasks <span class="badge badge-success"> 7 </span> </a> </li>
            <li class="divider"> </li>
            <li> <a href="lockscreen.html"> <i class="icon-lock"></i> Lock Screen </a> </li>
            <li> <a href="login.html"> <i class="icon-key"></i> Log Out </a> </li>
          </ul>
        </li>
        <!-- END USER LOGIN DROPDOWN -->
      </ul>
    </div>
    <!-- END TOP NAVIGATION MENU -->
  </div>
  <!-- END HEADER INNER -->
</div>
<div class="clearfix"> </div>
<div class="page-container">
<!-- Start page sidebar wrapper -->
<div class="page-sidebar-wrapper">
  <div class="page-sidebar sidebar-light">
    <ul class="page-sidebar-menu  page-header-fixed ">
      
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-th-large"></i> <span class="title">Dashboard</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="index.html"> <span class="title">Dashboard 1</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="dashboard2.html"> <span class="title">Dashboard 2</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="dashboard3.html"> <span class="title">Dashboard 3</span> </a> </li>
          <li class="nav-item">
                                <a class="nav-link" href="dashboard4.html"> <span class="title">Dashboard 4</span> </a>
                            </li>
<li class="nav-item">
                                <a class="nav-link" href="dashboard5.html"> <span class="title">Dashboard 5</span> </a>
                            </li>
<li class="nav-item">
                                <a class="nav-link" href="dashboard6.html"> <span class="title">Dashboard 6</span> </a>
                            </li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link" href="widgets.html"> <i class="fa fa-flash"></i> <span class="title">Widget</span> </a></li>

<li class="nav-item"> <a class="nav-link" href="animate.html"> <i class="fa fa-magic"></i> <span class="title">CSS Animations</span> </a></li>
<li class="heading">
<h3 class="uppercase">Features</h3>
      </li>
      <li class="nav-item active open"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-diamond"></i> <span class="title">UI Features</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="ui_colors.html" > <span class="title">Color Library</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="ui_buttons.html"> <span class="title">Buttons</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="ui_icons.html" > <span class="title">Font Icons</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="ui_tabs.html"> <span class="title">Tabs</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="timeline.html"> <span class="title">Timeline</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="timeline_horizontal.html"> <span class="title">Timeline Horizontal</span> </a> </li>
          <li class="nav-item active"> <a class="nav-link" href="ui_form.html"> <span class="title">Form UI</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="ui_grids.html"> <span class="title">Grids</span> </a> </li>
          
          <li class="nav-item"> <a class="nav-link" href="ui_typography.html"> <span class="title">Typography</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="alerts_Modal_Tooltip.html"> <span class="title">Alerts & Modal</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="badges_labels_progress.html"> <span class="title">Badges, Labels & Progress</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="MediaObjects_Thumbnails.html"> <span class="title">Media Objects</span> </a> </li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-flask"></i> <span class="title">Components</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="components_datetime_pickers.html"> <span class="title">Date &amp; Time Pickers</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_colourPikar.html"> <span class="title">Color Pickers</span> <span class="badge badge-danger">8</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_dropDown.html"> <span class="title">Dropdowns</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_multi_select.html"> <span class="title">Multi Select</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_fileinput.html" > <span class="title">Bootstrap File Input</span></a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_autocomplete.html"> <span class="title">Autocomplete</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_RangeSlider.html"> <span class="title">RangeSlider</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_Image_Cropping.html"> <span class="title">Image Cropping</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="components_Text_Editing.html"> <span class="title">Text Editor</span> </a> </li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-table"></i> <span class="title">Tables</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link nav-toggle" href="table_static_basic.html"> <span class="title">Static Tables</span> </a> </li>
          <li class="nav-item"> <a class="nav-link nav-toggle" href="table_datatables.html"> <span class="title">Datatables</span> </a> </li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-bar-chart-o"></i> <span class="title">Charts</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="graph_amcharts.html"> <span class="title">amChart</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="graph_chartjs.html"> <span class="title">ChartJS</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="graph_flotchart.html"> <span class="title">Flot Charts</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="graph_google.html"> <span class="title"> Google Charts </span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="graph_morris.html"> <span class="title"> Morris Chart </span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="graph_peity.html"> <span class="title"> Peity Chart </span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="graph_sparkline.html"> <span class="title"> Sparkline Charts </span> </a> </li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-map"></i> <span class="title">Maps</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="maps_google.html" > <span class="title">Google Maps</span> </a> </li>
          <li class="nav-item  "><a class="nav-link" href="maps_vector.html"><span class="title">Vector Maps</span> </a></li>
        </ul>
      </li>
      <li class="heading">
        <h3 class="uppercase">Layouts</h3>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-layers"></i> <span class="title">Page Layouts</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="layout_blank_page.html"> <span class="title">Blank Page</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="../../boxed-layouts-vertical-menu/LTR/index.html"> <span class="title">Boxed Layouts Vertical Menu</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="../../boxed-layouts-horizontal-menu/LTR/index.html"> <span class="title">Boxed Layouts Horizontal Menu</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="../../horizontal-menu-full-width/LTR/index.html"> <span class="title">Horizontal Menu Full Width</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="index.html"> <span class="title">Vertical Menu Template Nav Dark</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="../../vertical-menu-nav-light/LTR/index.html"> <span class="title">Vertical Menu Template Nav Light</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="../../vertical-menu-semi-dark/LTR/index.html"> <span class="title">Vertical Semi Dark Menu</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="../../vertical-menu-semi-light/LTR/index.html"> <span class="title">Vertical Semi Light Menu</span> </a> </li>
<li class="nav-item"> <a class="nav-link" href="../../vertical-overlay-menu/LTR/index.html"> <span class="title">Vertical Overlay Menu</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="layout_footer_fixed.html"> <span class="title">Fixed Footer 

</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="layout_search_on_header.html"> <span class="title">Search On Header</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="layout_sidebar_closed.html"> <span class="title">Closed Sidebar</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="layout_sidebar_fixed.html"> <span class="title">Fixed Sidebar</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="layout_sidebar_menu_light.html"> <span class="title">Light Sidebar Menu</span> </a> </li>
          
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-paper-plane"></i> <span class="title">Horizontal Menu</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link" href="layout_menu_dark.html"> <span class="title">Dark Horizontal Menu </span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="layout_menu_light.html"> <span class="title">Light Horizontal Menu </span> </a> </li>
        </ul>
      </li>
      <li class="heading">
        <h3 class="uppercase">Pages</h3>
      </li>
      <li > <a class="nav-link nav-toggle" href="javascript:;"><i class="fa fa-envelope"></i> <span class="title">Mailbox </span><span class="label label-warning pull-right">16/70</span></a>
        <ul class="sub-menu" >
          <li class="nav-item"><a class="nav-link" href="mailbox.html">Inbox</a></li>
          <li class="nav-item"><a class="nav-link" href="mail_detail.html">Email view</a></li>
          <li class="nav-item"><a class="nav-link" href="mail_compose.html">Compose email</a></li>
          <li class="nav-item"><a class="nav-link" href="email_template.html">Email templates</a></li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link" href="calendar.html"> <i class="icon-calendar"></i> <span class="title">Calendar</span> </a> </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-shopping-cart"></i> <span class="title">E-commerce</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"><a class="nav-link" href="ecommerce_products_grid1.html">Products grid I</a></li>
          <li class="nav-item"><a class="nav-link" href="ecommerce_products_grid2.html">Products grid II </a></li>
          <li class="nav-item"><a class="nav-link" href="ecommerce_product_list.html">Products list</a></li>
          <li class="nav-item"><a class="nav-link" href="ecommerce_product_detail.html">Product detail</a></li>
          <li class="nav-item"><a class="nav-link" href="ecommerce-cart.html">Cart</a></li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-picture-o"></i> <span class="title">Gallery</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"><a class="nav-link" href="lightbox_gallery.html">Lightbox Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="slick_carousel.html">Slick Carousel</a></li>
          <li class="nav-item"><a class="nav-link" href="carousel.html">Bootstrap Carousel</a></li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-desktop"></i> <span class="title">Apps</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"><a class="nav-link" href="projects.html">Projects</a></li>
          <li class="nav-item"><a class="nav-link" href="calendar.html">Calendar</a></li>
          <li class="nav-item"><a class="nav-link" href="issue_tracker.html">Issue tracker</a></li>
          <li class="nav-item"><a class="nav-link" href="blog.html">Blog</a></li>
          <li class="nav-item"><a class="nav-link" href="article.html">Article</a></li>
          <li class="nav-item"><a class="nav-link" href="faq.html">FAQ</a></li>
          <li class="nav-item"> <a class="nav-link" href="timeline.html" > <span class="title">Timeline</span> </a> </li>
          <li class="nav-item"> <a class="nav-link" href="timeline_horizontal.html"> <span class="title">Timeline Horizontal</span> </a> </li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="icon-user"></i> <span class="title">User</span> <span class="arrow"></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"><a class="nav-link" href="profile.html">Profile</a></li>
          <li class="nav-item"><a class="nav-link" href="profile_2.html">Profile-2</a></li>
          <li class="nav-item"><a class="nav-link" href="contacts.html">Contacts</a></li>
          <li class="nav-item"><a class="nav-link" href="contacts_2.html">Contacts-2</a></li>
          <li class="nav-item"><a class="nav-link" href="search_results.html">Search results</a></li>
          <li class="nav-item"><a class="nav-link" href="lockscreen.html">Lockscreen</a></li>
          <li class="nav-item"><a class="nav-link" href="invoice.html">Invoice</a></li>
          <li class="nav-item"><a class="nav-link" href="login.html">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="login_v2.html">Login 2</a></li>
          <li class="nav-item"><a class="nav-link" href="forgot_password.html">Forget password</a></li>
          <li class="nav-item"><a class="nav-link" href="register.html">Register</a></li>
          <li class="nav-item"><a class="nav-link" href="register_v2.html">Register 2</a></li>
          <li class="nav-item"><a class="nav-link" href="404.html">404 Page</a></li>
          <li class="nav-item"><a class="nav-link" href="500.html">500 Page</a></li>
        </ul>
      </li>
      <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> <i class="fa fa-sitemap"></i> <span class="title">Multi Level Menu</span> <span class="arrow "></span> </a>
        <ul class="sub-menu">
          <li class="nav-item"> <a class="nav-link nav-toggle" href="javascript:;"> Item 1 <span class="arrow"></span> </a>
            <ul class="sub-menu">
              <li class="nav-item"> <a class="nav-link" href="javascript:;"> Arrow Toggle <span class="arrow nav-toggle"></span> </a>
                <ul class="sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
                </ul>
              </li>
              <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
              <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 2</a> </li>
              <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 3</a> </li>
            </ul>
          </li>
          <li class="nav-item"> <a class="nav-link" href="javascript:;"> Arrow Toggle <span class="arrow nav-toggle"></span> </a>
            <ul class="sub-menu">
              <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
              <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
              <li class="nav-item"> <a class="nav-link" href="#"> Sample Link 1</a> </li>
            </ul>
          </li>
          <li class="nav-item"> <a class="nav-link" href="#"> Item 3 </a> </li>
        </ul>
      </li>
    </ul>
  </div>
</div>
<!-- End page sidebar wrapper -->
<!-- Start page content wrapper -->
<div class="page-content-wrapper animated fadeInRight">
  <div class="page-content" >
    <div class="wrapper border-bottom page-heading">
      <div class="col-lg-12">
        <h2> Form Stuff </h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
            <li class="breadcrumb-item"> <a>UI Features</a> </li>
          <li class="breadcrumb-item active"> <strong> Form Stuff </strong> </li>
        </ol>
      </div>
    </div>
    <div class="wrapper-content ">
      <div class="row">
        <!-- Basic Form start -->
        <div class="col-lg-6">
          <div class="ibox float-e-margins">
            <div class="widgets-container">
              <h5>Basic Form </h5>
              <hr>
              <form method="POST" action="<?php echo e(url('/editf', array($courses -> c_id))); ?>">
              <?php echo csrf_field(); ?>
              <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert-heading">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              <div class="form-group">
                  <label for="fname">Course Name</label>
                  <input class="form-control m-t-xxs" id="cname" name="cname" value="<?php echo $courses->cname ; ?>" placeholder="Enter cname" type="text">
                </div>
                
                <div class="form-check">
                  <label>
                  <input class="form-check-input iCheck" type="checkbox">
                  Check me out </label>
                </div>
                <button type="submit" class="btn  mb-0 aqua m-t-xs bottom15-xs">Submit</button>
              </form>
            </div>
          </div>
        </div>
        <!-- Basic Form End -->

    <!-- -->
    </div>
    </div>
<!-- start footer -->
<div class="footer">
      <div class="pull-right">
        <ul class="list-inline">
          <li><a title="" href="index.html">Dashboard</a></li>
          <li><a title="" href="mailbox.html"> Inbox </a></li>
          <li><a title="" href="blog.html">Blog</a></li>
          <li><a title="" href="contacts.html">Contacts</a></li>
        </ul>
      </div>
      <div> <strong>Copyright</strong> The Wolf Company &copy; 2017 </div>
    </div>
  </div>
</div>
<!-- Go top -->
<a href="#" class="scrollup"><i class="fa fa-chevron-up"></i></a>
<!-- Go top -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(url('/js/vendor/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/vendor/validator.js')); ?>"></script>
<!-- icheck -->
<script src="<?php echo e(url('/js/vendor/icheck.js')); ?>"></script>
<!-- bootstrap js -->
<script src="<?php echo e(url('/js/vendor/tether.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/vendor/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('/js/vendor/jquery.dataTables.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('/js/vendor/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- slimscroll js -->
<script type="text/javascript" src="<?php echo e(url('/js/vendor/jquery.slimscroll.js')); ?>"></script>
<!-- pace js -->
<script src="<?php echo e(url('/js/vendor/pace/pace.min.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(url('/js/main.js')); ?>"></script>
<script>
 $(function () {
  $('#myForm').validator();
});

  $(document).ready(function(){
            var callbacks_list = $('.demo-callbacks ul');
            $('input.iCheck').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
              callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
            }).iCheck({
               checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
              increaseArea: '20%'
            });
          });

</script>
<!-- demo  -->
<script src="<?php echo e(url('/js/appdemo.js')); ?>"></script>

<!-- start theme config -->
<div class="theme-config hidden-lg-down">
    <div class="theme-config-box">
        <div class="spin-icon"> <i class="fa fa-cogs fa-spin"></i> </div>
        <div class="skin-setttings">
            <div class="title">Configuration</div>
            <div class="setings-item"> <span> Collapse menu </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="collapsemenu" class="onoffswitch-checkbox" id="collapsemenu" type="checkbox">
                        <label class="onoffswitch-label" for="collapsemenu">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Fixed sidebar </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedsidebar" class="onoffswitch-checkbox" id="fixedsidebar" type="checkbox">
                        <label class="onoffswitch-label" for="fixedsidebar">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Header Fixed </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="headerfixed" class="onoffswitch-checkbox" id="headerfixed" type="checkbox" checked>
                        <label class="onoffswitch-label" for="headerfixed">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="setings-item"> <span> Fixed footer </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedfooter" class="onoffswitch-checkbox" id="fixedfooter" type="checkbox">
                        <label class="onoffswitch-label" for="fixedfooter">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="title">Navigation Color</div>


            <!-- Nav tabs -->
            <ul class="nav nav-tabs nav-justified" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Semi Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Semi Dark</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab">Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Dark</a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active semi-light" id="home" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>

                </div>
                <div class="tab-pane semi-dark" id="profile" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
                <div class="tab-pane light" id="messages" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>

                    </div>
                </div>
                <div class="tab-pane dark" id="settings" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
            </div>

            <div class="title">Sidebar Options</div>

            <div class="text-center m-3">
                <div class="btn-group">
                    <button class="btn btn-white sidebar-Light" type="button">Light</button>
                    <button class="btn dark sidebar-Dark" type="button">Dark</button>
                </div>
            </div>

            <div class="setings-item gohome "> <span class="skin-name"> <a href="../../index.html"> Go to Lending Page </a> </span> </div>
        </div>
    </div>
</div>
<!-- end theme config -->
</body>

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/ui_form.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:47:49 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\fileupload\resources\views/updatecourse.blade.php ENDPATH**/ ?>