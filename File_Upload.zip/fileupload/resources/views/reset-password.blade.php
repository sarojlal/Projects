<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/forgot_password.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
<head>
	<meta charset="utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>The Wolf</title>
	<!-- Bootstrap -->
	<link href="{{url('css/bootstrap.min.css')}}" rel="stylesheet">
	<!-- slimscroll -->
	<link href="{{url('css/jquery.slimscroll.css')}}" rel="stylesheet">
	<!-- Fontes -->
	<link href="{{url('css/font-awesome.min.css')}}" rel="stylesheet">
	<link href="{{url('css/glyphicons.css')}}" rel="stylesheet">
	<link href="{{url('css/simple-line-icons.css')}}" rel="stylesheet">
	<!-- all buttons css -->
	<link href="{{url('css/buttons.css')}}" rel="stylesheet">
	<!-- animate css -->
<link href="{{url('css/animate.css')}}" rel="stylesheet">
<!-- The Wolf main css -->
	<link href="{{url('css/main.css')}}" rel="stylesheet">
	<!-- theme css -->
	<link href="{{url('css/theme.css')}}" rel="stylesheet">
	<!-- media css for responsive  -->
	<link href="{{url('css/main.media.css')}}" rel="stylesheet">

<!-- demo  -->
<link href="{{url('css/appdemo.css')}}" rel="stylesheet">
	<!--[if lt IE 9]> <script src={{url('http://html5shim.googlecode.com/svn/trunk/html5.js')}}"></script> <![endif]-->
	<!--[if lt IE 9]> <script src={{url('dist/html5shiv.js')}}"></script> <![endif]-->
</head>

<body class="login">
	<div class="logo">
		<a href="index.html"> <img src="{{url('images/w-logo.png')}}" alt=""> </a>
	</div>
	<div class="passwordBox">
		<div class="row">
			<div class="col-md-12">
				<div class="widgets-container">
					<h2 class="font-bold">Forgot password</h2>
					<p> Enter your new password to reset the old one. </p>
					<div class="row">
						<div class="col-lg-12">
                        @if(session('status'))
                        <div class="alert alert-block alert-danger ">
                            <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                            <h4 class="alert-heading">Warning!</h4>
                            {{session('status')}}
                        </div>
                        @endif
							<form action="{{ url('/reset-password-final', array($faculties -> f_id)) }}" action="POST" class="top15">
                            <div class="form-group">
                                <label for="fname">Hey <?php echo $faculties->fname ; ?>,</label>
                            </div>
								<div class="form-group">
									<input type="password" required="" name="password" placeholder="Enter New Password" class="form-control">
								</div>
								<button class="btn aqua block bottom15" type="submit">Change Password</button>
								<a href="{{url('/')}}" class="btn aqua btn-outline pull-right ">Back</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 login-copyright"> <strong>Copyright</strong> The Wolf Company &copy; 2017-2017 </div>
		</div>
	</div>
<!-- demo  -->


<!-- start theme config -->
<div class="theme-config hidden-lg-down">
    <div class="theme-config-box">
        <div class="spin-icon"> <i class="fa fa-cogs fa-spin"></i> </div>
        <div class="skin-setttings">
            <div class="title">Configuration</div>
            <div class="setings-item"> <span> Collapse menu </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="collapsemenu" class="onoffswitch-checkbox" id="collapsemenu" type="checkbox">
                        <label class="onoffswitch-label" for="collapsemenu">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Fixed sidebar </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedsidebar" class="onoffswitch-checkbox" id="fixedsidebar" type="checkbox">
                        <label class="onoffswitch-label" for="fixedsidebar">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Header Fixed </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="headerfixed" class="onoffswitch-checkbox" id="headerfixed" type="checkbox" checked>
                        <label class="onoffswitch-label" for="headerfixed">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="setings-item"> <span> Fixed footer </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedfooter" class="onoffswitch-checkbox" id="fixedfooter" type="checkbox">
                        <label class="onoffswitch-label" for="fixedfooter">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="title">Navigation Color</div>


            <!-- Nav tabs -->
            <ul class="nav nav-tabs nav-justified" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Semi Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Semi Dark</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab">Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Dark</a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active semi-light" id="home" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>

                </div>
                <div class="tab-pane semi-dark" id="profile" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
                <div class="tab-pane light" id="messages" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>

                    </div>
                </div>
                <div class="tab-pane dark" id="settings" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
            </div>

            <div class="title">Sidebar Options</div>

            <div class="text-center m-3">
                <div class="btn-group">
                    <button class="btn btn-white sidebar-Light" type="button">Light</button>
                    <button class="btn dark sidebar-Dark" type="button">Dark</button>
                </div>
            </div>

            <div class="setings-item gohome "> <span class="skin-name"> <a href="../../index.html"> Go to Lending Page </a> </span> </div>
        </div>
    </div>
</div>
<!-- end theme config -->
</body>


<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/forgot_password.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
</html>