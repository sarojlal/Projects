@include('student_header')
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Assignments</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                @if(session('info'))
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    {{session('info')}}
                  </div>
                  @endif
                  
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                    <thead>
                        <tr>
                          <th>Assignment ID</th>
                          <th>Assignment Name</th>
                          <th>Description</th>
                          <th>Faculty Name</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                        <th>Assignment ID</th>
                          <th>Assignment Name</th>
                          <th>Description</th>
                          <th>Faculty Name</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        @if(count($assigs) > 0)
                        @foreach($assigs->all() as $assig)
                        @if($students[0]->course === $assig->course && $students[0]->sem === $assig->sem_id && $students[0]->class === $assig->class )

                         <tr>
                         <td>{{$assig->assig_id}}</td>
                         <td>{{$assig->document}}</td>
                         <td>{{$assig->desc}}</td>
                         <td>
                         @if(count($faculties) > 0)
                                @foreach($faculties -> all() as $faculty)
                                    @if($faculty->f_id == $assig->f_id)
                                        {{$faculty->fname}}
                                    @endif
                                @endforeach
                         @endif
                         </td>
                                <td>
                                <a href="assignment/{{$assig -> document}}" download="{{$assig -> document}}" class="green btn btn-outline btn-xs"><i class="fa fa-download"></i></a>
                                </td>
                                </tr>
                            @endif
                            @endforeach
                        @endif
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <table>
                 
                      </tbody>
                    </table>
      @include('footer')