<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>The Wolf</title>
<!-- Bootstrap -->
<link href="{{url('css/bootstrap.min.css')}}" rel="stylesheet">
<!-- icheck -->
<link href="{{url('css/skins/all.css')}}" rel="stylesheet">
<!-- slimscroll -->
<link href="{{url('css/jquery.slimscroll.css')}}" rel="stylesheet">
<!-- Fontes -->
<link href="{{url('css/font-awesome.min.css')}}" rel="stylesheet">
	<link href="{{url('css/glyphicons.css')}}" rel="stylesheet">
<link href="{{url('css/simple-line-icons.css')}}" rel="stylesheet">
<!-- all buttons css -->
<link href="{{url('css/buttons.css')}}" rel="stylesheet">
<!-- animate css -->
<link href="{{url('css/animate.css')}}" rel="stylesheet">
<!-- The Wolf main css -->
<link href="{{url('css/main.css')}}" rel="stylesheet">
<!-- theme css -->
<link href="{{url('css/theme.css')}}" rel="stylesheet">
<!-- media css for responsive  -->
<link href="{{url('css/main.media.css')}}" rel="stylesheet">

<!-- demo  -->
<link href="{{url('css/appdemo.css')}}" rel="stylesheet">
<!--[if lt IE 9]> <script src="http://html5shim.googlecode.com/svn/trunk/html5.js')}}"></script> <![endif]-->
<!--[if lt IE 9]> <script src="dist/html5shiv.js')}}"></script> <![endif]-->
<script src="{{url('js/vendor/jquery.min.js')}}"></script>
<!-- Script to call c_id through jquery -->
<script>
    $(document).ready(function(){
        $("#course").on('change',load_new_content);
    });
    function load_new_content(){
        var selected = $(this).val();
        var select = {'course' : $(this).value};
        //alert(selected);
        //alert(select);
        $.ajax({
            url:"StudentsController@register/"+selected,
            type:'GET',
            dataType:'json',
            data:{
                selected
            },
            success: function(data){
                $('#showid').text(data);
                alert(data);
            },
            error:function(e){
                console.log("Error");
            }

        });
    }
</script>
<!-- Script to hide/show -->
<script type="text/javascript">
        $(function () {
            $("#course").change(function () {
                if ($(this).val() == "-1") {
                    $("#1").hide();
					$("#2").hide();
					}
                    
		  });
        });
</script>
		<script type="text/javascript">
        $(function () {
            $("#course").change(function () {
                if ($(this).val() == "1") {
                    $("#1").show();
					$("#2").hide();
					}
                    
		  });
        });
		
		$(function () {
            $("#course").change(function () {
                if ($(this).val() == "2") {
                    $("#2").show();
					$("#1").hide();
				} 
                    
		  });
        });
    </script>
<!-- Script complete-->

</head>
<body class="login">
<div class="middle-box text-center loginscreen   ">
  <div class="widgets-container">
    <div>
      <h1 class="logo-name">WOLF</h1>
    </div>
    <h3>Register to The Wolf</h3>
    <p>Create account to see it in action.</p>
    <form action="{{ url('/insertstud') }}" method="POST" class="m-t">
    @csrf
      <div class="form-group">
        <input type="text" required="" placeholder="Enroll No" name="enroll_no" id="enroll_no" class="form-control">
      </div>
      <div class="form-group">
        <input type="text" required="" placeholder="Name" name="sname" id="sname" class="form-control">
      </div>
      <div class="form-group">
        <input type="email" required="" placeholder="Email" name="semail" id="semail" class="form-control">
      </div>
      <div class="form-group">
        <input type="password" required="" placeholder="Password" name="spwd" id="spwd" class="form-control">
      </div>
      <!-- <div class="form-group">
        <input type="text" required="" placeholder="Course" name="course" id="course" class="form-control">
      </div> -->
      
      <div class="form-group" id="formgroup">
        <select name="course" class="form-control" id="course">
        <option value="-1" selected disabled>--Select Course--</option>
        @if(count($courses) > 0)
            @foreach($courses -> all() as $course)
            <option value="{{$course->c_id}}">
                {{$course->cname}}
            </option>
            @endforeach
        @endif
        </select>
      </div>
      <!-- <div class="form-group">
        <input type="text" required="" placeholder="Sem" name="sem" id="sem" class="form-control">
      </div> -->
      <div class="form-group" style="display:none" id="1">
        <select name="sem" onchange="" class="form-control">
        <option value="-1" selected disabled>--Select Sem for MCA--</option>
        @if(count($qry1) > 0)
                @foreach($qry1 as $qry)
                    <option value="{{$qry->sem_id}}" >
                        {{$qry->sem}}
                    </option>
                @endforeach
        @endif
        </select>
      </div>
      <div class="form-group" style="display:none" id="2">
        <select name="sem" onchange="" class="form-control">
        <option value="-1" selected disabled>--Select Sem for IMCA--</option>
        @if(count($qry2) > 0)
                @foreach($qry2 as $q1)
                    <option value="{{$q1->sem_id}}" >
                        {{$q1->sem}}
                    </option>
                @endforeach
        @endif
        </select>
      </div>
      <div class="form-group">
        <select name="class" class="form-control">
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
        </select>
      </div>
      <div class="form-group">
        <div class="i-checks">
          <input type="checkbox" class="iCheck" indeterminate="true">
          Agree the terms and policy </div>
      </div>
      <button class="btn aqua block full-width m-b" type="submit">Register</button>
      <p class="text-muted text-center"><small>Already have an account?</small></p>
      <a href="{{url('/')}}" class="btn btn-sm btn-white btn-block">Login</a>
    </form>
    <p class="top15"> <small>The Wolf is easy to use and customize &copy; 2016-2017</small> </p>
  </div>
</div>
<!-- demo  -->
<script src="{{url('js/appdemo.js')}}"></script>

<!-- start theme config -->
<div class="theme-config hidden-lg-down">
    <div class="theme-config-box">
        <div class="spin-icon"> <i class="fa fa-cogs fa-spin"></i> </div>
        <div class="skin-setttings">
            <div class="title">Configuration</div>
            <div class="setings-item"> <span> Collapse menu </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="collapsemenu" class="onoffswitch-checkbox" id="collapsemenu" type="checkbox">
                        <label class="onoffswitch-label" for="collapsemenu">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Fixed sidebar </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedsidebar" class="onoffswitch-checkbox" id="fixedsidebar" type="checkbox">
                        <label class="onoffswitch-label" for="fixedsidebar">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Header Fixed </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="headerfixed" class="onoffswitch-checkbox" id="headerfixed" type="checkbox" checked>
                        <label class="onoffswitch-label" for="headerfixed">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="setings-item"> <span> Fixed footer </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedfooter" class="onoffswitch-checkbox" id="fixedfooter" type="checkbox">
                        <label class="onoffswitch-label" for="fixedfooter">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="title">Navigation Color</div>


            <!-- Nav tabs -->
            <ul class="nav nav-tabs nav-justified" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Semi Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Semi Dark</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab">Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Dark</a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active semi-light" id="home" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>

                </div>
                <div class="tab-pane semi-dark" id="profile" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
                <div class="tab-pane light" id="messages" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>

                    </div>
                </div>
                <div class="tab-pane dark" id="settings" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
            </div>

            <div class="title">Sidebar Options</div>

            <div class="text-center m-3">
                <div class="btn-group">
                    <button class="btn btn-white sidebar-Light" type="button">Light</button>
                    <button class="btn dark sidebar-Dark" type="button">Dark</button>
                </div>
            </div>

            <div class="setings-item gohome "> <span class="skin-name"> <a href="../../index.html"> Go to Lending Page </a> </span> </div>
        </div>
    </div>
</div>
<!-- end theme config -->
</body>
<!-- Go top -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

<!-- icheck -->
<script src="{{url('js/vendor/icheck.js')}}"></script>
<!-- bootstrap js -->
<script src="{{url('js/vendor/tether.min.js')}}"></script>
<script src="{{url('js/vendor/bootstrap.min.js')}}"></script>
	<script type="text/javascript" src="{{url('js/vendor/jquery.dataTables.js')}}"></script>
	<script type="text/javascript" src="{{url('js/vendor/dataTables.bootstrap4.min.js')}}"></script>
<!-- pace js -->
<script src="{{url('js/vendor/pace/pace.min.js')}}"></script>
<!-- main js -->
<script src="{{url('js/main.js')}}"></script>
<script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-green',
            });
        });
    </script>

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:59:51 GMT -->
</html>
