@include('student_header')
  <!-- End page sidebar wrapper -->
  <!-- Start page content wrapper -->
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2> Student Assignment Upload </h2>
        </div>
        <div class="col-lg-12"> 
        <div class="form-group row">
            
        </div>
      </div>
      
                    <!-- Script to hide/show -->
                    <script type="text/javascript">
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "-1") {
                                        $("#1").hide();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                    
                            $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "1") {
                                        $("#1").show();
                              $("#2").hide();
                              }
                                        
                          });
                            });
                        
                        $(function () {
                                $("#course").change(function () {
                                    if ($(this).val() == "2") {
                                        $("#2").show();
                              $("#1").hide();
                            } 
                                        
                          });
                            });
                        </script>
                    <!-- Script complete-->
      <!-- File Upload Starts -->
      <form action="{{url('/studassig-store')}}" method="POST" enctype="multipart/form-data" class="m-t">
            @csrf
                    <!-- <div class="form-group"> -->
                    <!-- <label class="custom-file">
                        <input type="file" name="uploads" id="file" class="custom-file-input">
                        <span class="custom-file-control"></span>
                    </label> -->
                    
                    <div class="form-group row">
                        <label for="assignment">Choose File</label>
                        <input class="form-control" type="file" name="assignment" id="assignment" >
                        
                    </div>
                    
                    <!-- Elements of different models -->
                    <div class="form-group row" id="formgroup">
                    <label for="course">Select Assignment</label>
                      <select name="ass_id" class="form-control" id="ass_id">
                      <option value="-1" selected disabled>--Select Assignment--</option>
                      @if(count($assigs) > 0)
                        @foreach($assigs -> all() as $assig)
                        @if($students[0]->course === $assig->course && $students[0]->sem === $assig->sem_id && $students[0]->class === $assig->class )
                        <option value="{{$assig->assig_id}}" >
                            {{$assig->document}}
                        </option>
                        @endif
                        @endforeach
                    @endif
                      </select>
                    </div>

                    <div class="form-group row" id="formgroup">
                    <label for="course">Select Faculty</label>
                      <select name="fid" class="form-control" id="fid">
                      <option value="-1" selected disabled>--Select Faculty--</option>
                      @if(count($faculties) > 0)
                          @foreach($faculties -> all() as $faculty)
                          <option value="{{$faculty->f_id}}">
                              {{$faculty->fname}}
                          </option>
                          @endforeach
                      @endif
                      </select>
                    </div>
                    <!-- <div class="form-group">
                      <input type="text" required="" placeholder="Sem" name="sem" id="sem" class="form-control">
                    </div> -->
                    <!-- Elements of different models Ends -->

                    <div class="form-group row">  
                  <button class="btn  mb-0 aqua" type="submit">Submit</button>
                <div/>
                </div>
            </form>
             <!-- File upload completes -->
      
@include('footer')