@include('adminheader')

<!-- End page sidebar wrapper -->
<!-- Start page content wrapper -->
<div class="page-content-wrapper animated fadeInRight">
  <div class="page-content" >
    <div class="wrapper border-bottom page-heading">
      <div class="col-lg-12">
        <h2> Form Stuff </h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
            <li class="breadcrumb-item"> <a>UI Features</a> </li>
          <li class="breadcrumb-item active"> <strong> Add Course </strong> </li>
        </ol>
      </div>
    </div>
    <div class="wrapper-content ">
      <div class="row">
        <!-- Basic Form start -->
        <div class="col-lg-12">
          <div class="ibox float-e-margins">
            <div class="widgets-container">
    <h3>Insert Faculty</h3>
    <form action="{{ url('/insertfacul') }}" method="POST" class="m-t">
    @csrf
      <div class="form-group">
        <input type="text" required="" placeholder="Name" name="fname" id="fname" class="form-control">
      </div>
      <div class="form-group">
        <input type="email" required="" placeholder="Email" name="femail" id="femail" class="form-control">
      </div>
      <div class="form-group">
        <input type="password" required="" placeholder="Password" name="fpwd" id="fpwd" class="form-control">
      </div>
      <div class="form-group">
        <div class="i-checks">
          <input type="checkbox" class="iCheck" indeterminate="true">
          Agree the terms and policy </div>
      </div>
      <button class="btn aqua block full-width m-b" type="submit">Insert</button>
    </form>
    </div>
          </div>
        </div>
        <!-- Basic Form End -->

    <!-- -->
    </div>
    </div>
<!-- start footer -->
<div class="footer">
      <div class="pull-right">
        <ul class="list-inline">
          <li><a title="" href="index.html">Dashboard</a></li>
          <li><a title="" href="mailbox.html"> Inbox </a></li>
          <li><a title="" href="blog.html">Blog</a></li>
          <li><a title="" href="contacts.html">Contacts</a></li>
        </ul>
      </div>
      <div> <strong>Copyright</strong> The Wolf Company &copy; 2017 </div>
    </div>
  </div>
</div>
<!-- Go top -->
<a href="#" class="scrollup"><i class="fa fa-chevron-up"></i></a>
<!-- Go top -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="{{url('/js/vendor/jquery.min.js')}}"></script>
<script src="{{url('/js/vendor/validator.js')}}"></script>
<!-- icheck -->
<script src="{{url('/js/vendor/icheck.js')}}"></script>
<!-- bootstrap js -->
<script src="{{url('/js/vendor/tether.min.js')}}"></script>
<script src="{{url('/js/vendor/bootstrap.min.js')}}"></script>
	<script type="text/javascript" src="{{url('/js/vendor/jquery.dataTables.js')}}"></script>
	<script type="text/javascript" src="{{url('/js/vendor/dataTables.bootstrap4.min.js')}}"></script>
<!-- slimscroll js -->
<script type="text/javascript" src="{{url('/js/vendor/jquery.slimscroll.js')}}"></script>
<!-- pace js -->
<script src="{{url('/js/vendor/pace/pace.min.js')}}"></script>
<!-- main js -->
<script src="{{url('/js/main.js')}}"></script>
<script>
 $(function () {
  $('#myForm').validator();
});

  $(document).ready(function(){
            var callbacks_list = $('.demo-callbacks ul');
            $('input.iCheck').on('ifCreated ifClicked ifChanged ifChecked ifUnchecked ifDisabled ifEnabled ifDestroyed', function(event){
              callbacks_list.prepend('<li><span>#' + this.id + '</span> is ' + event.type.replace('if', '').toLowerCase() + '</li>');
            }).iCheck({
               checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
              increaseArea: '20%'
            });
          });

</script>
<!-- demo  -->
<script src="{{url('/js/appdemo.js')}}"></script>

<!-- start theme config -->
<div class="theme-config hidden-lg-down">
    <div class="theme-config-box">
        <div class="spin-icon"> <i class="fa fa-cogs fa-spin"></i> </div>
        <div class="skin-setttings">
            <div class="title">Configuration</div>
            <div class="setings-item"> <span> Collapse menu </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="collapsemenu" class="onoffswitch-checkbox" id="collapsemenu" type="checkbox">
                        <label class="onoffswitch-label" for="collapsemenu">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Fixed sidebar </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedsidebar" class="onoffswitch-checkbox" id="fixedsidebar" type="checkbox">
                        <label class="onoffswitch-label" for="fixedsidebar">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>
            <div class="setings-item"> <span> Header Fixed </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="headerfixed" class="onoffswitch-checkbox" id="headerfixed" type="checkbox" checked>
                        <label class="onoffswitch-label" for="headerfixed">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="setings-item"> <span> Fixed footer </span>
                <div class="switch">
                    <div class="onoffswitch">
                        <input name="fixedfooter" class="onoffswitch-checkbox" id="fixedfooter" type="checkbox">
                        <label class="onoffswitch-label" for="fixedfooter">
            <span class="onoffswitch-inner"></span>
            <span class="onoffswitch-switch"></span>
            </label>
                    </div>
                </div>
            </div>

            <div class="title">Navigation Color</div>


            <!-- Nav tabs -->
            <ul class="nav nav-tabs nav-justified" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Semi Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Semi Dark</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab">Light</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Dark</a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active semi-light" id="home" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>

                </div>
                <div class="tab-pane semi-dark" id="profile" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
                <div class="tab-pane light" id="messages" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box gray-bg" data="gray-bg.html"> </div>
                        <div class="theme-color-box white-bg" data="white-bg.html"> </div>

                    </div>
                </div>
                <div class="tab-pane dark" id="settings" role="tabpanel">
                    <div class="text-center">
                        <div class="theme-color-box blue-bg" data="blue-bg.html"> </div>
                        <div class="theme-color-box yellow-bg" data="yellow-bg.html"> </div>
                        <div class="theme-color-box red-bg" data="red-bg.html"> </div>
                        <div class="theme-color-box black-bg" data="black-bg.html"> </div>
                        <div class="theme-color-box dark-grey-bg" data="dark-grey-bg.html"> </div>
                        <div class="theme-color-box dark-madison-bg" data="dark-madison-bg.html"> </div>
                        <div class="theme-color-box dark-black-bg" data="dark-black-bg.html"> </div>
                        <div class="theme-color-box orange-bg" data="orange-bg.html"> </div>
                        <div class="theme-color-box green-bg" data="green-bg.html"> </div>
                        <div class="theme-color-box aqua-bg" data="aqua-bg.html"> </div>
                        <div class="theme-color-box purple-bg" data="purple-bg.html"> </div>
                    </div>
                </div>
            </div>

            <div class="title">Sidebar Options</div>

            <div class="text-center m-3">
                <div class="btn-group">
                    <button class="btn btn-white sidebar-Light" type="button">Light</button>
                    <button class="btn dark sidebar-Dark" type="button">Dark</button>
                </div>
            </div>

            <div class="setings-item gohome "> <span class="skin-name"> <a href="../../index.html"> Go to Lending Page </a> </span> </div>
        </div>
    </div>
</div>
<!-- end theme config -->
</body>

<!-- Mirrored from thewolf.bittyfox.com/vertical-menu-nav-dark/LTR/ui_form.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Jul 2019 12:47:49 GMT -->
</html>
