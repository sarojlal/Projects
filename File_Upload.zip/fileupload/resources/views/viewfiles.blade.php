@include('student_header')
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Uploads</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                @if(session('info'))
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    {{session('info')}}
                  </div>
                  @endif
                  
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                    <thead>
                        <tr>
                          <th>File ID</th>
                          <th>File Name</th>
                          <th>Faculty Name</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>File ID</th>
                          <th>File Name</th>
                          <th>Faculty Name</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        @if(count($uploads) > 0)
                        @foreach($uploads->all() as $upload)
                        
                        @if($students[0]->course === $upload->course && $students[0]->sem === $upload->sem && $students[0]->class === $upload->class )

                         <tr>
                         <td>{{$upload->uid}}</td>
                         <td>{{$upload->uploads}}</td>
                         
                         
                         <td>
                         @if(count($faculties) > 0)
                                @foreach($faculties -> all() as $faculty)
                                    @if($faculty->f_id === $upload->f_id)
                                        {{$faculty->fname}}
                                    @endif
                                @endforeach
                         @endif
                         </td>       
                                <td>
                                    <a href="uploads/{{$upload -> uploads}}" download="{{$upload -> uploads}}" class="green btn btn-outline btn-xs"><i class="fa fa-download"></i></a>
                                    <a href='{{url("/deleteupload/{$upload->uid}")}}' class="red btn btn-outline btn-xs"><i class="fa fa-trash"></i></a>
                                </td>
                                </tr>
                            
                            @endif
                            @endforeach
                        @endif
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <table>
                 
                      </tbody>
                    </table>
      @include('footer')