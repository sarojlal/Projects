Hey {{$user}},you are getting this email because you requested reset password in our portal.<br>
<p>
Reset Password Link:<a href="{{$name}}">{{$name}}</a>
</p>