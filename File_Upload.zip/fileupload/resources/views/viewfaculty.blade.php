@include('inc.header')

@if(session('info'))
    <div class="col-mg-6 alert alert-success">
    {{session('info')}}
    </div>
@endif
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Password</th>
    </tr>
  </thead>
  <tbody>
    @if(count($faculties) > 0)
        @foreach($faculties -> all() as $faculty)
            <tr>
            <td>{{$faculty -> f_id}}</td>
            <td>{{$faculty -> fname}}</td>
            <td>{{$faculty -> femail}}</td>
            <td>{{$faculty -> fpwd}}</td>
            <td>
                <a href="{{url('/login')}}" class="label label-primary">Read</a>
                <a href='{{url("/update/{$faculty->f_id}")}}' class="label label-success">Update</a>
                <a href='{{url("/delete/{$faculty->f_id}")}}' class="label label-danger">Delete</a>
            </td>
            </tr>
        @endforeach
    @endif
  </tbody>
</table>

@include('inc.footer')
