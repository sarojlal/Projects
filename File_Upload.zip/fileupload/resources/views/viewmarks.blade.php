@include('student_header')
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Assignments</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                @if(session('info'))
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    {{session('info')}}
                  </div>
                  @endif
                  
                  <div class="row">
                  <div class="col-lg-12" >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                    <thead>
                        <tr>
                          <th>Mark ID</th>
                          <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited(Student)</th>
                          <th>Faculty Name</th>
                          <th>Marks</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                        <th>Mark ID</th>
                        <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited(Student)</th>
                          <th>Faculty Name</th>
                          <th>Marks</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        @if(count($marks) > 0)
                        @foreach($marks->all() as $mark)
                        @if( $mark->stud_id == Auth::guard('student')->user()->sid )

                         <tr>
                         <td>{{$mark->mid}}</td>
                         <td>
                              @foreach($assigs->all() as $assig)
                              @if($assig->assig_id == $mark->assig_id)
                                {{$assig->document}}
                              @endif
                              @endforeach
                         </td>
                         <td>{{$mark->assig_name}}</td>
                         <td>
                         @if(count($faculties) > 0)
                                @foreach($faculties -> all() as $faculty)
                                    @if($faculty->f_id == $mark->f_id)
                                        {{$faculty->fname}}
                                    @endif
                                @endforeach
                         @endif
                         </td>
                                <td>{{$mark->marks}}</td>
                                </tr>
                            @endif
                            @endforeach
                        @endif
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <table>
                 
                      </tbody>
                    </table>
      @include('footer')