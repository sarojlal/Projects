@include('header')

<p>Hello</p>

@include('footer')