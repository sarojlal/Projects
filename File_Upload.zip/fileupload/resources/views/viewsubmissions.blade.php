@include('header')
<div class="page-content-wrapper animated fadeInRight">
    <div class="page-content">
      <div class="wrapper border-bottom page-heading">
        <div class="col-lg-12">
          <h2>View Submissions</h2>
        </div>
        <div class="col-lg-12"> </div>
      </div>
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Buttons Extension Demos</h5>
              </div>
              <div class="ibox-content collapse show">
                <div class="widgets-container">
                @if(session('info'))
                  <div class="alert alert-block alert-success ">
                    <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                    <h4 class="alert-heading">Success!</h4>
                    {{session('info')}}
                  </div>
                  @endif
                  <div class="row">
                  <div class="col-lg-12" >
                  <form method="POST" action='{{ url("/submitmarks") }}'>
                    @csrf
                    @if(count($errors) > 0)
                    @foreach($errors->all() as $error)
                        <div class="alert-heading">
                            {{$error}}
                        </div>
                    @endforeach
                    @endif
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                       <thead>
                        <tr>
                          <th>Assignment ID</th>
                          <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited (Student)</th>
                          <th>Description</th>
                          <th>Student Name</th>
                          <th>Marks</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>Assignment ID</th>
                          <th>Assignment Name(Faculty)</th>
                          <th>Assignment Submited (Student)</th>
                          <th>Description</th>
                          <th>Student Name</th>
                          <th>Marks</th>
                          <th>Actions</th>
                        </tr>
                      </tfoot>
                      <tbody>
                      
                        @if(count($studassigs) > 0)
                            @foreach($studassigs -> all() as $assig)
                            @foreach($assigs -> all() as $ass)
                            
                            @if($ass->assig_id == $assig->ass_id)
                                <tr>
                                
                                <td>
                                <input type="hidden" name="assig_id" value="{{$assig -> ass_id}}" />
                                {{$assig -> ass_id}}
                                </td>
                                <td>
                                <input type="hidden" name="assig_name_faculty" value="{{$ass -> document}}" />
                                {{$ass -> document}}
                                </td>
                                <td>
                                <input type="hidden" name="assig_name" value="{{$assig->assignment}}" />
                                {{$assig->assignment}}
                                </td>
                                <td>{{$ass->desc}}</td>
                                <td>
                                <input type="hidden" name="stud_id" value="{{$students[0]->sid}}" />
                                {{$students[0]->sname}}
                                </td>
                                <td>
                                <input type="number" min=0 max=10 name="marks" placeholder="Marks" style="width:60px;height:20px" />
                                <!-- <a href='{{url("/submitmarks")}}' class="green btn btn-outline btn-xs"><i class="fa fa-eye"></i>Submit Marks</a> -->
                                <button class="btn btn-primary" type="submit" style="width:30px;height:20px"><i class="fa fa-check"></i></button>
                                </td>
                                <td>
                                    <a href="../stud-assignment/{{$assig -> assignment}}" download="{{$assig -> assignment}}" class="green btn btn-outline btn-xs"><i class="fa fa-download"></i></a>
                                    
                                </td>
                                </tr>
                            @endif
                            @endforeach
                            @endforeach
                        @endif
                      </tbody>
                    </table>
                    </form>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      @include('footer')